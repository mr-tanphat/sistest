<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


require_once('include/connectors/sources/ext/rest/rest.php');
class ext_rest_inbox25 extends ext_rest {
	protected $_enable_in_wizard = false;
	protected $_enable_in_hover = false;
	protected $_enable_in_admin_properties = false;
	protected $_enable_in_admin_mapping = false;
	protected $_enable_in_admin_search = false;
	protected $_has_testing_enabled = false;

    	protected $orgId;
    	protected $orgName;
    	protected $userId;
    	public static $allowedModuleList;
    
    public function __construct() {
        
        global $app_list_strings;
        $this->allowedModuleList = array('Leads' => $app_list_strings['moduleList']['Leads'],
        				 'Prospects' => $app_list_strings['moduleList']['Prospects'],
						  'Accounts' => $app_list_strings['moduleList']['Accounts'],
						  'Opportunities' => $app_list_strings['moduleList']['Opportunities'],

                                         'Contacts' => $app_list_strings['moduleList']['Contacts']);

        parent::__construct();
    }

    public function filterAllowedModules( $moduleList ) {
        // InsideView currently has no ability to talk to modules other than these four
        $outModuleList = array();
        foreach ( $moduleList as $module ) {
            if ( !in_array($module,$this->allowedModuleList) ) {
                continue;
            } else {
                $outModuleList[$module] = $module;
            }
        }
        return $outModuleList;
    }

    public function saveMappingHook($mapping) {

        $removeList = array();
        foreach ($this->allowedModuleList as $module_name=>$display_name) {
            $removeList[$module_name] = $module_name;
        }

        if ( is_array($mapping['beans']) ) {
            foreach($mapping['beans'] as $module => $ignore) {
                unset($removeList[$module]);
                
                check_logic_hook_file($module, 'after_ui_frame', array(1, $module. ' InsideView frame', 'modules/Connectors/connectors/sources/ext/rest/inbox25/InboxViewLogicHook.php', 'InboxViewLogicHook', 'showFrame') );
            }
        }

        foreach ( $removeList as $module ) {
            remove_logic_hook($module, 'after_ui_frame', array(1, $module. ' InboxView frame', 'modules/Connectors/connectors/sources/ext/rest/inbox25/InboxViewLogicHook.php', 'InboxViewLogicHook', 'showFrame') );
        }

        return parent::saveMappingHook($mapping);
    }

    

	public function getItem($args=array(), $module=null){}
	public function getList($args=array(), $module=null) {}


    public function ext_allowInboxView( $request ) {
        $GLOBALS['current_user']->setPreference('allowInboxView',1,0,'Connectors');
        return true;
    }
}
