<?php


$mapping = array (
  'beans' => 
  array (
    'Accounts' => 
    array (
    ),
    'Contacts' => 
    array (
    ),
    'Leads' => 
    array (
    ),
    'Opportunities' => 
    array (
    ),
  ),
);
?>
