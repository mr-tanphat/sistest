<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$config = array (
  'name' => 'Inbox25',
  'order' => 65,
  'properties' => array (
      ),
);
