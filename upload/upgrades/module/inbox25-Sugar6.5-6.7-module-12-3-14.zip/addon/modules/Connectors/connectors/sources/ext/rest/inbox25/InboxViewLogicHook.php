<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class InboxViewLogicHook {

    const urlBase = 'http://www.google.com/';

    protected function handleFieldMap($bean, $mapping) {
        $outArray = array();
        foreach ( $mapping as $dest => $src ) {
            // Initialize it to an empty string, so it is always set
            $outArray[$dest] = '';

            if ( is_array($src) ) {
                // The source can be any one of a number of fields
                // we must go deeper.
                foreach ( $src as $src2 ) {
                    if ( isset($bean->$src2) ) {
                        $outArray[$dest] = $bean->$src2;
                        break;
                    }
                }
            } else {
                if ( isset($bean->$src) ) {
                    $outArray[$dest] = $bean->$src;
                }
            }
        }

        $outStr = '';
        foreach ( $outArray as $k => $v ) {
            $outStr .= $k.'='.rawurlencode(html_entity_decode($v,ENT_QUOTES)).'&';
        }
        
        $outStr = rtrim($outStr,'&');
        
        return $outStr;
    }

    public function showFrame($event, $args) {
		global $db,$currentModule;
	require_once('include/connectors/utils/ConnectorUtils.php');
			require_once('include/connectors/sources/SourceFactory.php');

			$connectors = ConnectorUtils::getConnectors();
			$connector_keys = array_keys($connectors);
			$modules_sources = ConnectorUtils::getDisplayConfig();
			if ( !is_array($modules_sources) ) {
			    $modules_sources = (array) $modules_sources;
			}
			if(!$modules_sources[$currentModule]['ext_rest_inbox25']){
            return;

}
        if ( $GLOBALS['app']->controller->action != 'DetailView' ) {
            return;
        }
        require_once('include/connectors/utils/ConnectorUtils.php');

        $bean = $GLOBALS['app']->controller->bean;

        // Build the base arguments
        static $userFieldMap = array('crm_user_id' => 'id',
                                     'crm_user_fn' => 'first_name',
                                     'crm_user_ln' => 'last_name',
                                     'crm_user_email' => 'email1',
        );

	$url = '';        

    // Check if the user should be shown the frame or not
	$smarty = new Sugar_Smarty();
	$tplName = 'modules/Connectors/connectors/sources/ext/rest/inbox25/tpls/InboxView.tpl';

	global $current_user, $mod_strings, $app_strings, $app_list_strings, $sugar_config, $locale,$db;
	$res = $db->query("select * from iframeapp where deleted=0 and created_by = '".$current_user->id."'");
	$row = $db->fetchByAssoc($res);

	$iframe_src = $row['iframe_src'];
	$iframe_height = $row['iframe_height'];

	if($iframe_height=='') $iframe_height = '800';
	$smarty->assign('IFRAME_HEIGHT', $iframe_height);            

	if($iframe_src!='') {
		$cipher = "rijndael-128";
		$mode = "cbc";
		$secret_key = "ge8C2mWu9jLraK5v";
		$iv = "fedcba9876543210";
		$plain_text = time();

		$td = mcrypt_module_open($cipher, "", $mode, $iv);
		mcrypt_generic_init($td, $secret_key, $iv);
		$cyper_text = mcrypt_generic($td, $plain_text);
		mcrypt_generic_deinit($td);
		mcrypt_module_close($td);

		$ts = bin2hex($cyper_text);
		if( $bean->object_name == 'Opportunity' ) {
			$smarty->assign('IFRAME_SRC', $iframe_src.'&sugar_id_opp='.$bean->id.'&ts='.$ts);
		} else {
			$smarty->assign('IFRAME_SRC', $iframe_src.'&sugar_id='.$bean->id.'&ts='.$ts);
		}	
	} else {
		$smarty->assign('IFRAME_SRC', 'https://www.inbox25.com/timelinefail.php');
	}		
	echo $smarty->fetch($tplName);
    }
}
