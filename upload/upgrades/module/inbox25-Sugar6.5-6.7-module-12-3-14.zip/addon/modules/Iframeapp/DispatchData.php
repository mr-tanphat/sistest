<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

include_once("modules/Iframeapp/Iframeapp.php");
class DispatchData {
	var $url;

	function ProcessMod($bean, $event, $arguments){
		//ini_set('display_errors',false);

		global $current_user,$db;
		static $called_inbox25=0;
		$timestamp1 = strtotime('now') + date('Z');
		//echo $_REQUEST['action'];die;
		$action_type='Import';
		if(isset($_REQUEST['action']) && $_REQUEST['action']=='MassUpdate'){
		$action_type='mass_update';
		}
		if((isset($_REQUEST['action']) && $_REQUEST['action']=='Step4' || $_REQUEST['action']=='MassUpdate') && !$called_inbox25){
		$_SESSION['import_id'] =uniqid();
		$_SESSION['timestamp_inbox'] =$timestamp1;
		$called_inbox25 =1;

		$postdata = array(
				'sugar_module' => $bean->module_dir,
				'sugar_id' => $bean->id,
				'action_type' => $action_type,
				'action_time' =>$timestamp1,
				'import_id' =>$_SESSION['import_id'],
			);
			//die("ashish");
			$ret = $this->sendData($postdata,'');

		}
		elseif($called_inbox25 ==1){
			//die("you are done");
		return;
		}
		elseif($event=='after_relationship_add' || $event=='after_relationship_delete'){
			$called_inbox25 =1;

			$postdata = array(
				'sugar_module' => $bean->module_dir,
				'sugar_id' => $bean->id,
				'action_type' => $event,
				'action_time' =>$timestamp1,
			);
			
			$ret = $this->sendData($postdata,'');		
		}
		elseif(isset($_REQUEST['action']) && $_REQUEST['action']=='Undo'){
			$postdata = array(
				'sugar_module' => $bean->module_dir,
				'sugar_id' => $bean->id,
				'action_type' => 'Undo_Import',
				'action_time' =>$_SESSION['timestamp_inbox'],
				'import_id' =>$_SESSION['import_id'],
			);
			
			$ret = $this->sendData($postdata,'');
			
		}
		else{
				$iframe_obj = new Iframeapp();
				
				$res = $db->query("select id from iframeapp where deleted=0 and created_by = '".$current_user->id."'");
				$row = $db->fetchByAssoc($res);
				//echo $row['id'];die;
				if($row['id']) $iframe_obj->retrieve($row['id']);		

				if( trim($iframe_obj->iframe_src) != '' ) {
					$domain_details = parse_url($iframe_obj->iframe_src);		

					$domain = $domain_details['host'];
					$query_string = $domain_details['query'];			
					$dataUrl = 'http://'.$domain.'/listener.php';
					$this->url = $dataUrl;
					
					$query_part = explode("&",$query_string);
					$logic_hook_enable = 1;
					foreach( $query_part as $part ) {
						if( $part == 'ma=0') {
							$logic_hook_enable = 0;
							break;
						}
					}
					
					if( $logic_hook_enable == 0 ) return;
								
					if( @$bean->date_entered == $bean->date_modified )
						$action_type = 'add';
					else	
						$action_type = 'edit';
					
					if( $bean->deleted == 1 ) $action_type = 'delete';

					$sugar_email = '';
					$opt_out = 0;
					$invalid_email = 0;
					if (isset($bean->emailAddress->addresses)) {
						foreach( $bean->emailAddress->addresses as $item ) {
							if( $item['primary_address'] == 1 ) {
								$sugar_email = $item['email_address'];
								$invalid_email = $item['invalid_email'];
								$opt_out = $item['opt_out'];
								break;
							}
						}
					}

					$postdata = array(
						'sugar_module' => $bean->module_dir,
						'sugar_id' => $bean->id,
						'sugar_email' => $sugar_email,
						'invalid_email' => $invalid_email,
						'opt_out' => $opt_out,
						'action_type' => $action_type
					);
					//die("ashish");
					$ret = $this->sendData($postdata,$query_string);		
				}
		}
	}
	
	function ProcessRel($bean, $event, $arguments){
		global $current_user,$db;
		
		$iframe_obj = new Iframeapp();
		
		$res = $db->query("select id from iframeapp where deleted=0 and created_by = '".$current_user->id."'");
		$row = $db->fetchByAssoc($res);
		
		if($row['id']) $iframe_obj->retrieve($row['id']);		

		if( trim($iframe_obj->iframe_src) != '' ) {
			$domain_details = parse_url($iframe_obj->iframe_src);		
			
			$domain = $domain_details['host'];
			$query_string = $domain_details['query'];			
			$dataUrl = 'http://'.$domain.'/listener.php';
			$this->url = $dataUrl;
			
			$query_part = explode("&",$query_string);
			$logic_hook_enable = 1;
			foreach( $query_part as $part ) {
				if( $part == 'ma=0') {
					$logic_hook_enable = 0;
					break;
				}
			}
			
			if( $logic_hook_enable == 0 ) return;			
						
			$action_type = 'rel';
			$sugar_email = '';
			$opt_out = 0;
			$invalid_email = 0;
			if (isset($bean->emailAddress->addresses)) {
				foreach( $bean->emailAddress->addresses as $item ) {
					if( $item['primary_address'] == 1 ) {
						$sugar_email = $item['email_address'];
						$invalid_email = $item['invalid_email'];
						$opt_out = $item['opt_out'];
						break;
					}
				}
			}

			$postdata = array(
				'sugar_module' => $arguments['module'],
				'sugar_id' => $arguments['id'],
				'sugar_email' => $sugar_email,
				'invalid_email' => $invalid_email,
				'opt_out' => $opt_out,
				'action_type' => $action_type
			);
			$ret = $this->sendData($postdata,$query_string);		
		}
	}
	
	function ProcessDelRel($bean, $event, $arguments){
		global $current_user,$db;
		
		$iframe_obj = new Iframeapp();
		
		$res = $db->query("select id from iframeapp where deleted=0 and created_by = '".$current_user->id."'");
		$row = $db->fetchByAssoc($res);
		
		if($row['id']) $iframe_obj->retrieve($row['id']);		

		if( trim($iframe_obj->iframe_src) != '' ) {
			$domain_details = parse_url($iframe_obj->iframe_src);		
			
			$domain = $domain_details['host'];
			$query_string = $domain_details['query'];			
			$dataUrl = 'http://'.$domain.'/listener.php';
			$this->url = $dataUrl;
						
			$action_type = 'rel';			

			$postdata = array(
				'sugar_module' => $arguments['module'],
				'sugar_id' => $arguments['id'],
				'action_type' => $action_type
			);
			$ret = $this->sendData($postdata,$query_string);		
		}
	}	
	
	function sendData($postdata,$query_string) {
		//die("You are here");
		global $current_user,$db;
		if(!$query_string){
			$iframe_obj = new Iframeapp();
		
		$res = $db->query("select id from iframeapp where deleted=0 and created_by = '".$current_user->id."'");
		$row = $db->fetchByAssoc($res);
		//echo $row['id'];die;
		if($row['id']) $iframe_obj->retrieve($row['id']);		

			if( trim($iframe_obj->iframe_src) != '' ) {
				$domain_details = parse_url($iframe_obj->iframe_src);		

				$domain = $domain_details['host'];
				$query_string = $domain_details['query'];			
				$dataUrl = 'http://'.$domain.'/listener.php';
				$this->url = $dataUrl;
				
				$query_part = explode("&",$query_string);
				$logic_hook_enable = 1;
				foreach( $query_part as $part ) {
					if( $part == 'ma=0') {
						$logic_hook_enable = 0;
						break;
					}
				}
			}
		}
		$ch = curl_init($this->url);
		
		$poststr = $query_string;
		foreach( $postdata as $fldname=>$fldval ) {
			$poststr .= '&'.$fldname.'='.$fldval;
		}

		curl_setopt($ch, CURLOPT_POST      ,1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $poststr);
		curl_setopt($ch, CURLOPT_HEADER      ,0); 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER  ,1);
		curl_setopt($ch, CURLOPT_TIMEOUT  ,10);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);		
		return $return_data = curl_exec($ch);		
	}
}
?>