<?php


$mod_strings['LBL_SCORE'] = 'INBOX25 Score';


?>