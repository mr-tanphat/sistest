<?php
// created: 2013-02-08 07:58:06
$dictionary["Contact"]["fields"]["in25_score"] = array (
  'name' => 'in25_score',
  'type' => 'varchar',
 
  'vname' => 'LBL_SCORE',
);
