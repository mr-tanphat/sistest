<?php
function post_install() {

	global $db;
	
	include_once("modules/Users/User.php");
	
	$res = $db->query("truncate iframeapp");

	include("modules/ACL/install_actions.php");

	sugar_cache_reset();


    require_once('modules/ModuleBuilder/parsers/ParserFactory.php');
   generate_panel("Accounts");
	generate_panel("Leads");
   generate_panel("Prospects");
   generate_panel("Contacts");

    return;

}
function generate_panel($module){
 $view_array = ParserFactory::getParser('detailview',$module);
 
    $new_content = array
    (
        0 => array
        (
            0 => array
            (
                'name' => 'inbox25_score_c',
                'label' => 'LBL_SCORE',
            ),
           
        ),
    );

    $view_array->_viewdefs['panels']['Inbox25'] = $new_content;
 
    $view_array->handleSave(false);
}
?>
