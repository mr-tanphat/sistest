<?PHP
/**
 *
 * LICENSE: The contents of this file are subject to the license agreement ("License") which is included
 * in the installation package (LICENSE.txt). By installing or using this file, you have unconditionally
 * agreed to the terms and conditions of the License, and you may not use this file except in compliance
 * with the License.
 *
 * @author     Original Author Biztech Co.
 */

/**
 * THIS CLASS IS FOR DEVELOPERS TO MAKE CUSTOMIZATIONS IN
 */
require_once('modules/bc_submission_data/bc_submission_data_sugar.php');
class bc_submission_data extends bc_submission_data_sugar {
	
	function bc_submission_data(){	
		parent::bc_submission_data_sugar();
	}
	
}
?>