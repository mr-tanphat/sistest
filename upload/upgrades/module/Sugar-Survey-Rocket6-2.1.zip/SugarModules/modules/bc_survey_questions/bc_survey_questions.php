<?PHP
/**
 *
 * LICENSE: The contents of this file are subject to the license agreement ("License") which is included
 * in the installation package (LICENSE.txt). By installing or using this file, you have unconditionally
 * agreed to the terms and conditions of the License, and you may not use this file except in compliance
 * with the License.
 *
 * @author     Original Author Biztech Co.
 */

/**
 * THIS CLASS IS FOR DEVELOPERS TO MAKE CUSTOMIZATIONS IN
 */
require_once('modules/bc_survey_questions/bc_survey_questions_sugar.php');
class bc_survey_questions extends bc_survey_questions_sugar {
	
	function bc_survey_questions(){	
		parent::bc_survey_questions_sugar();
	}
	
}
?>