<?php
/**
 * When uninstall package and remove all plugin's files from the instance.
 *
 * LICENSE: The contents of this file are subject to the license agreement ("License") which is included
 * in the installation package (LICENSE.txt). By installing or using this file, you have unconditionally
 * agreed to the terms and conditions of the License, and you may not use this file except in compliance
 * with the License.
 *
 * @author     Original Author Biztech Co.
 */
if (!defined('sugarEntry'))
    define('sugarEntry', true);

removeSendSurveyButtonFromSupportModule();
post_uninstall();

function post_uninstall() {
    global $db;

    // restore the original files
    $file = 'custom/modules/Accounts/views/view.detail_survey_bkp_orig.php';
    $newfile = 'custom/modules/Accounts/views/view.detail.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Accounts/views/view.list_survey_bkp_orig.php';
    $newfile = 'custom/modules/Accounts/views/view.list.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }


    $file = 'custom/modules/Contacts/views/view.detail_survey_bkp_orig.php';
    $newfile = 'custom/modules/Contacts/views/view.detail.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Contacts/views/view.list_survey_bkp_orig.php';
    $newfile = 'custom/modules/Contacts/views/view.list.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $file = 'custom/modules/Leads/views/view.detail_survey_bkp_orig.php';
    $newfile = 'custom/modules/Leads/views/view.detail.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Leads/views/view.list_survey_bkp_orig.php';
    $newfile = 'custom/modules/Leads/views/view.list.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $file = 'custom/modules/Prospects/views/view.detail_survey_bkp_orig.php';
    $newfile = 'custom/modules/Prospects/views/view.detail.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Prospects/views/view.list_survey_bkp_orig.php';
    $newfile = 'custom/modules/Prospects/views/view.list.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $file = 'custom/modules/Users/views/view.detail_survey_bkp_orig.php';
    $newfile = 'custom/modules/Users/views/view.detail.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Users/views/view.list_survey_bkp_orig.php';
    $newfile = 'custom/modules/Users/views/view.list.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/EmailTemplates/EditView_survey_bkp_orig.html';
    $newfile = 'custom/modules/EmailTemplates/EditView.html';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $file = 'custom/modules/EmailTemplates/EditViewMain_survey_bkp_orig.html';
    $newfile = 'custom/modules/EmailTemplates/EditViewMain.html';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $file = 'custom/modules/EmailTemplates/EditView_survey_bkp_orig.php';
    $newfile = 'custom/modules/EmailTemplates/EditView.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $SchedulerQry = "UPDATE schedulers set deleted = 1 WHERE job = 'function::sendScheduledSurveys'";
    $result = $db->query($SchedulerQry);

    $configQuery = "DELETE FROM config where category='SurveyPlugin'";
    $db->query($configQuery);
}

function removeSendSurveyButtonFromSupportModule() {
    require_once('modules/ModuleBuilder/parsers/ParserFactory.php');
    $survey_modules_layouts = array(
        'Accounts' => 'detailview',
        'Contacts' => 'detailview',
        'Leads' => 'detailview',
        'Prospects' => 'detailview',
    );

    foreach ($survey_modules_layouts as $module => $view) {
        $view_array = ParserFactory::getParser($view, $module);
        foreach ($view_array->_viewdefs['templateMeta']['form']['buttons'] as $key => $button) {
            if (is_array($button) && in_array('{$send_survey}', $button)) {
                unset($view_array->_viewdefs['templateMeta']['form']['buttons'][$key]);
                $view_array->handleSave(false);
            }
        }
    }
}

function recursiveRemove($dir) {
    $structure = glob(rtrim($dir, "/") . '/*');
    if (is_array($structure)) {
        foreach ($structure as $file) {
            if (is_dir($file))
                recursiveRemove($file);
            elseif (is_file($file))
                unlink($file);
        }
    }
}

global $db;
if ($_REQUEST['remove_tables'] == 'true') {
    $sql_module_1 = "ALTER TABLE email_templates
                     DROP survey_id, DROP survey_module_type";
    $db->query($sql_module_1);
    
    $sql_module_2 = "DROP TABLE bc_survey_submit_answer_calculation";
    $db->query($sql_module_2); 
    
    recursiveRemove("custom/include/Image_question/");
    recursiveRemove("custom/include/surveylogo_images/");
}
