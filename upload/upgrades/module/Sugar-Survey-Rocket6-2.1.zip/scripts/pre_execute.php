<?php

/**
 * pre-execute when installing the plugin.
 *
 * LICENSE: The contents of this file are subject to the license agreement ("License") which is included
 * in the installation package (LICENSE.txt). By installing or using this file, you have unconditionally
 * agreed to the terms and conditions of the License, and you may not use this file except in compliance
 * with the License.
 *
 * @author     Original Author Biztech Co.
 */
if (!defined('sugarEntry'))
    define('sugarEntry', true);
pre_execute();

function pre_execute() {
    global $db, $current_user;
    require_once('ModuleInstall/PackageManager/PackageManager.php');
    
    $pm = new PackageManager();
    $installeds = $pm->getinstalledPackages();
   
    foreach ($installeds as $package) {
        if ($package['name'] == 'Survey Rocket') {
            echo "<script type='text/javascript'> alert('Survey Rocket Plugin already exists. First Uninstall existing Survey Rocket plugin. Please click on display log for more information.');</script>";
        
            echo "<br/>Survey Rocket Plugin already exists. First Uninstall existing Survey Rocket plugin. <br/><br/> <input type='button' value='Back to Module Loader' onclick=\"javascript:parent.SUGAR.App.router.navigate('#bwc/index.php?module=Administration&action=UpgradeWizard&view=module', {trigger: true})\"> <br/><br/>";
            $GLOBALS['log']->fatal("Survey Rocket Plugin already exists. First Uninstall existing Survey Rocket plugin.");
            die();
        }
    } 
    // backup existing files
    $file = 'custom/modules/Accounts/views/view.detail.php';
    $newfile = 'custom/modules/Accounts/views/view.detail_survey_bkp_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Accounts/views/view.list.php';
    $newfile = 'custom/modules/Accounts/views/view.list_survey_bkp_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Contacts/views/view.detail.php';
    $newfile = 'custom/modules/Contacts/views/view.detail_survey_bkp_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Contacts/views/view.list.php';
    $newfile = 'custom/modules/Contacts/views/view.list_survey_bkp_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $file = 'custom/modules/Leads/views/view.detail.php';
    $newfile = 'custom/modules/Leads/views/view.detail_survey_bkp_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Leads/views/view.list.php';
    $newfile = 'custom/modules/Leads/views/view.list_survey_bkp_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $file = 'custom/modules/Prospects/views/view.detail.php';
    $newfile = 'custom/modules/Prospects/views/view.detail_survey_bkp_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Prospects/views/view.list.php';
    $newfile = 'custom/modules/Prospects/views/view.list_survey_bkp_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $file = 'custom/modules/Users/views/view.detail.php';
    $newfile = 'custom/modules/Users/views/view.detail_survey_bkp_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/Users/views/view.list.php';
    $newfile = 'custom/modules/Users/views/view.list_survey_bkp_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }
    $file = 'custom/modules/EmailTemplates/EditView.html';
    $newfile = 'custom/modules/EmailTemplates/EditView_survey_bkp_orig.html';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $file = 'custom/modules/EmailTemplates/EditViewMain.html';
    $newfile = 'custom/modules/EmailTemplates/EditViewMain_survey_bkp_orig.html';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $file = 'custom/modules/EmailTemplates/EditView.php';
    $newfile = 'custom/modules/EmailTemplates/EditView_survey_bkp_orig.php';
    if (file_exists($file)) {
        if (!rename($file, $newfile))
            echo "failed to rename $file...\n";
    }

    $file = 'custom/include/Image_question';
    if (!is_dir($file)) {
        mkdir($file);
        chmod($file, 0777);
    }
    
    $file1 = 'custom/include/surveylogo_images';
    if (!is_dir($file1)) {
        mkdir($file1);
        chmod($file1, 0777);
    }

    $guId = create_guid();
    $installDate = date("Y/m/d H:i:s");
    ;
    $SchedulerQry = "INSERT INTO schedulers
                                    (id,
                                     deleted,
                                     date_entered,
                                     date_modified,
                                     created_by,
                                     modified_user_id,
                                     NAME,
                                     job,
                                     date_time_start,
                                     date_time_end,
                                     job_interval,
                                     time_from,
                                     time_to,
                                     STATUS,
                                     catch_up)
                        VALUES ('{$guId}',
                                0,
                                '{$installDate}',
                                '{$installDate}',
                                '{$current_user->id}',
                                '{$current_user->id}',
                                'Send Scheduled Surveys Email',
                                'function::sendScheduledSurveys',
                                '2005-01-01 08:30:00',
                                NULL,
                                '*/15::*::*::*::*',
                                NULL,
                                NULL,
                                'Active',
                                1)";
    $db->query($SchedulerQry);

    //check bc_survey_submit_answer_calculation table exists or not
    $sql = $db->query("SHOW TABLES LIKE 'bc_survey_submit_answer_calculation'");

    //if table exists then alter by adding new column
    if ($sql->num_rows != 0) {
        $db->query("ALTER TABLE bc_survey_submit_answer_calculation  ADD question_id char(36) NOT NULL");
    }
    // if table not exist then create it
    else {
        if ($db->dbType == "mssql") {// check that current db is mssql or not for creating new table for bc_survey_submit_answer_calculation
            $db->query("IF NOT EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[notification_modules]') AND type in (N'U'))
                 CREATE TABLE IF NOT EXISTS bc_survey_submit_answer_calculation (
                    id char(36) NOT NULL,
                    answer_type varchar(100) DEFAULT NULL,
                    submit_answer_id text,
                    sent_survey_id char(36) DEFAULT NULL,
                    survey_receiver_id char(36) DEFAULT NULL,
                    question_id char(36) DEFAULT NULL
                  ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
        } else {
            $db->query("CREATE TABLE IF NOT EXISTS bc_survey_submit_answer_calculation (
                    id char(36) NOT NULL,
                    answer_type varchar(100) DEFAULT NULL,
                    submit_answer_id text,
                    sent_survey_id char(36) DEFAULT NULL,
                    survey_receiver_id char(36) DEFAULT NULL,
                    question_id char(36) DEFAULT NULL
                  ) ENGINE=InnoDB DEFAULT CHARSET=utf8");
        }
    }



    //
    require_once('modules/Administration/Administration.php');
    $administrationObj = new Administration();
    $administrationObj->saveSetting("SurveyPlugin", "LastValidation", 0);
    $administrationObj->saveSetting("SurveyPlugin", "LastValidationMsg", "Please validate Customer survey module license.");
    $administrationObj->saveSetting("SurveyPlugin", "ModuleEnabled", 0);
    $administrationObj->saveSetting("SurveyPlugin", "SurveyProductSKU", "sugarcrm-survey-rocket");
    $administrationObj->saveSetting("SurveyPlugin", "survey_url_for_email", "/survey_submission.php?survey_id=");
    $administrationObj->saveSetting("SurveyPlugin", "LicenseFrequency", 7);
}
