<?php
//auto-generated file DO NOT EDIT
/**
 *
 * LICENSE: The contents of this file are subject to the license agreement ("License") which is included
 * in the installation package (LICENSE.txt). By installing or using this file, you have unconditionally
 * agreed to the terms and conditions of the License, and you may not use this file except in compliance
 * with the License.
 *
 * @author     Original Author Biztech Co.
 */
$layout_defs['Contacts']['subpanel_setup']['bc_survey_submission_contacts']['override_subpanel_name'] = 'Contact_subpanel_bc_survey_submission_contacts';
?>