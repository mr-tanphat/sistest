<?php
/**
 *
 * LICENSE: The contents of this file are subject to the license agreement ("License") which is included
 * in the installation package (LICENSE.txt). By installing or using this file, you have unconditionally
 * agreed to the terms and conditions of the License, and you may not use this file except in compliance
 * with the License.
 *
 * @author     Original Author Biztech Co.
 */
//auto-generated file DO NOT EDIT
$layout_defs['Prospects']['subpanel_setup']['bc_survey_submission_prospects']['override_subpanel_name'] = 'Prospect_subpanel_bc_survey_submission_prospects';
?>