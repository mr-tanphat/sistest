<?php
// created: 2016-07-07 16:43:11
$dictionary["bc_survey_automizer"]["fields"]["bc_survey_automizer_bc_automizer_condition"] = array (
  'name' => 'bc_survey_automizer_bc_automizer_condition',
  'type' => 'link',
  'relationship' => 'bc_survey_automizer_bc_automizer_condition',
  'source' => 'non-db',
  'module' => 'bc_automizer_condition',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_BC_SURVEY_AUTOMIZER_BC_AUTOMIZER_CONDITION_FROM_BC_AUTOMIZER_CONDITION_TITLE',
);
