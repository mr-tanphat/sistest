<?php
// created: 2016-07-07 16:43:11
$dictionary["bc_survey_automizer"]["fields"]["bc_survey_automizer_bc_automizer_actions"] = array (
  'name' => 'bc_survey_automizer_bc_automizer_actions',
  'type' => 'link',
  'relationship' => 'bc_survey_automizer_bc_automizer_actions',
  'source' => 'non-db',
  'module' => 'bc_automizer_actions',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_BC_SURVEY_AUTOMIZER_BC_AUTOMIZER_ACTIONS_FROM_BC_AUTOMIZER_ACTIONS_TITLE',
);
