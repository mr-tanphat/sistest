Survey Rocket

Searching a solution for improving customer satisfaction? Your search comes to an end. We at Biztech
have developed the “Survey Rocket” Plugin to collect and store the valuable feedbacks of your
customers.

 Customer satisfaction is the key to success. Survey Rocket helps you to bridge the gap between
businesses and customers. It allows you to sneak into the hearts of your customers.
 Get to know the value of your products/services and the improvements required if any.
 Feedback could be helpful from marketing and sales point of view.
 Create eye catching surveys with industry specific themes and prebuilt questionnaires which the
customers will tend to fill up.
 The survey questionnaires can have different answer types.
 Generate various type of reports based on different statistics.

Prerequisites

Following points must be followed before starting Installation.

 You should login as an Administrator in SugarCRM.
 Check that your SugarCRM Instance is compatible for Survey Rocket.
 You must have a valid License Key Provided by Biztech Store.
 If you are installing Survey Rocket then make sure there should not be any older
version of Survey Rocket Plug-in already installed on SugarCRM. If there is any then
you will have to uninstall that plug-in first.
 Make sure that cron must be configured for the scheduler Jobs.
 Outbound email must be set for the SugarCRM system. Survey Emails uses the
SugarCRM Outbound Email Account.