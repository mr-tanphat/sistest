<?php 
 //WARNING: The contents of this file are auto-generated

 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/accounts_c_invoices_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/accounts_c_payments_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_submission_data_bc_survey_answersMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_submission_data_bc_survey_questionsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_submission_data_bc_survey_submissionMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_accountsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_answers_bc_survey_questionsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_automizer_bc_automizer_actionsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_automizer_bc_automizer_conditionMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_bc_survey_questionsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_bc_survey_templateMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_contactsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_leadsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_pages_bc_surveyMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_pages_bc_survey_questionsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_pages_bc_survey_templateMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_prospectsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_submission_accountsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_submission_bc_surveyMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_submission_contactsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_submission_leadsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_submission_prospectsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_submission_usersMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_template_bc_survey_questionsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_usersMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_contacts_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_c_invoices_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_c_payments_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_c_payments_2MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_c_refunds_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_j_feedback_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_j_payment_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_j_ptresult_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contracts_j_class_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contracts_meetings_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_classes_contacts_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_classes_contracts_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_classes_c_rooms_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_classes_c_teachers_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_classes_opportunities_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_contacts_contacts_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_contacts_leads_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_invoices_c_payments_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_invoices_opportunities_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_memberships_contacts_2MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_memberships_leads_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_packages_opportunities_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_payments_c_refunds_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_programs_c_classes_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_programs_c_packages_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_promotions_opportunities_1MetaData.php');


 
 // created: 2016-05-23 03:55:52

						include('custom/metadata/C_SMS_contacts.php');	
			
						
 
 // created: 2016-05-23 03:55:52

						include('custom/metadata/C_SMS_c_teachers.php');	
			
						
 
 // created: 2016-05-23 03:55:52

						include('custom/metadata/C_SMS_j_ptresult.php');	
			
						
 
 // created: 2016-05-23 03:55:52

						include('custom/metadata/C_SMS_j_studentsituations.php');	
			
						
 
 // created: 2016-05-23 03:55:52

						include('custom/metadata/C_SMS_leads.php');	
			
						
 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_sponsors_c_payments_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_teachers_j_gradebook_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_teachers_j_teachercontract_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_class_contacts_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_class_c_teachers_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_class_j_class_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_class_j_feedback_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_class_j_gradebook_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_class_leads_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_coursefee_j_class_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_coursefee_j_payment_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_discount_j_discount_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_discount_j_partnership_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_partnership_j_payment_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_payment_j_discount_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_payment_j_inventory_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_payment_j_payment_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_school_contacts_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_school_leads_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_school_prospects_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/leads_contacts_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/leads_c_payments_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/leads_j_ptresult_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/leads_leads_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/meetings_j_ptresult_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/opportunities_c_refunds_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/opportunities_meetings_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/users_j_feedback_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/users_j_feedback_2MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/users_j_marketingplan_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/users_j_marketingplan_2MetaData.php');


?>