<?php 
 //WARNING: The contents of this file are auto-generated

 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Attendance'] = 'C_Attendance';
$beanFiles['C_Attendance'] = 'modules/C_Attendance/C_Attendance.php';
$moduleList[] = 'C_Attendance';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Carryforward'] = 'C_Carryforward';
$beanFiles['C_Carryforward'] = 'modules/C_Carryforward/C_Carryforward.php';
$modules_exempt_from_availability_check['C_Carryforward'] = 'C_Carryforward';
$report_include_modules['C_Carryforward'] = 'C_Carryforward';
$modInvisList[] = 'C_Carryforward';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Class'] = 'J_Class';
$beanFiles['J_Class'] = 'modules/J_Class/J_Class.php';
$moduleList[] = 'J_Class';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Classes'] = 'C_Classes';
$beanFiles['C_Classes'] = 'modules/C_Classes/C_Classes.php';
$moduleList[] = 'C_Classes';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Commission'] = 'C_Commission';
$beanFiles['C_Commission'] = 'modules/C_Commission/C_Commission.php';
$modules_exempt_from_availability_check['C_Commission'] = 'C_Commission';
$report_include_modules['C_Commission'] = 'C_Commission';
$modInvisList[] = 'C_Commission';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_ConfigID'] = 'C_ConfigID';
$beanFiles['C_ConfigID'] = 'modules/C_ConfigID/C_ConfigID.php';
$modules_exempt_from_availability_check['C_ConfigID'] = 'C_ConfigID';
$report_include_modules['C_ConfigID'] = 'C_ConfigID';
$modInvisList[] = 'C_ConfigID';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_ConfigInvoiceNo'] = 'J_ConfigInvoiceNo';
$beanFiles['J_ConfigInvoiceNo'] = 'modules/J_ConfigInvoiceNo/J_ConfigInvoiceNo.php';
$moduleList[] = 'J_ConfigInvoiceNo';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Contacts'] = 'C_Contacts';
$beanFiles['C_Contacts'] = 'modules/C_Contacts/C_Contacts.php';
$moduleList[] = 'C_Contacts';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Coursefee'] = 'J_Coursefee';
$beanFiles['J_Coursefee'] = 'modules/J_Coursefee/J_Coursefee.php';
$moduleList[] = 'J_Coursefee';


 
 //WARNING: The contents of this file are auto-generated
$beanList['bc_submission_data'] = 'bc_submission_data';
$beanFiles['bc_submission_data'] = 'modules/bc_submission_data/bc_submission_data.php';
$modules_exempt_from_availability_check['bc_submission_data'] = 'bc_submission_data';
$report_include_modules['bc_submission_data'] = 'bc_submission_data';
$modInvisList[] = 'bc_submission_data';
$beanList['bc_survey_submission'] = 'bc_survey_submission';
$beanFiles['bc_survey_submission'] = 'modules/bc_survey_submission/bc_survey_submission.php';
$modules_exempt_from_availability_check['bc_survey_submission'] = 'bc_survey_submission';
$report_include_modules['bc_survey_submission'] = 'bc_survey_submission';
$modInvisList[] = 'bc_survey_submission';
$beanList['bc_survey_template'] = 'bc_survey_template';
$beanFiles['bc_survey_template'] = 'modules/bc_survey_template/bc_survey_template.php';
$moduleList[] = 'bc_survey_template';
$beanList['bc_survey'] = 'bc_survey';
$beanFiles['bc_survey'] = 'modules/bc_survey/bc_survey.php';
$moduleList[] = 'bc_survey';
$beanList['bc_survey_questions'] = 'bc_survey_questions';
$beanFiles['bc_survey_questions'] = 'modules/bc_survey_questions/bc_survey_questions.php';
$modules_exempt_from_availability_check['bc_survey_questions'] = 'bc_survey_questions';
$report_include_modules['bc_survey_questions'] = 'bc_survey_questions';
$modInvisList[] = 'bc_survey_questions';
$beanList['bc_survey_pages'] = 'bc_survey_pages';
$beanFiles['bc_survey_pages'] = 'modules/bc_survey_pages/bc_survey_pages.php';
$modules_exempt_from_availability_check['bc_survey_pages'] = 'bc_survey_pages';
$report_include_modules['bc_survey_pages'] = 'bc_survey_pages';
$modInvisList[] = 'bc_survey_pages';
$beanList['bc_survey_answers'] = 'bc_survey_answers';
$beanFiles['bc_survey_answers'] = 'modules/bc_survey_answers/bc_survey_answers.php';
$modules_exempt_from_availability_check['bc_survey_answers'] = 'bc_survey_answers';
$report_include_modules['bc_survey_answers'] = 'bc_survey_answers';
$modInvisList[] = 'bc_survey_answers';
$beanList['bc_survey_automizer'] = 'bc_survey_automizer';
$beanFiles['bc_survey_automizer'] = 'modules/bc_survey_automizer/bc_survey_automizer.php';
$moduleList[] = 'bc_survey_automizer';
$beanList['bc_automizer_condition'] = 'bc_automizer_condition';
$beanFiles['bc_automizer_condition'] = 'modules/bc_automizer_condition/bc_automizer_condition.php';
$modules_exempt_from_availability_check['bc_automizer_condition'] = 'bc_automizer_condition';
$report_include_modules['bc_automizer_condition'] = 'bc_automizer_condition';
$modInvisList[] = 'bc_automizer_condition';
$beanList['bc_automizer_actions'] = 'bc_automizer_actions';
$beanFiles['bc_automizer_actions'] = 'modules/bc_automizer_actions/bc_automizer_actions.php';
$modules_exempt_from_availability_check['bc_automizer_actions'] = 'bc_automizer_actions';
$report_include_modules['bc_automizer_actions'] = 'bc_automizer_actions';
$modInvisList[] = 'bc_automizer_actions';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_DeliveryRevenue'] = 'C_DeliveryRevenue';
$beanFiles['C_DeliveryRevenue'] = 'modules/C_DeliveryRevenue/C_DeliveryRevenue.php';
$modules_exempt_from_availability_check['C_DeliveryRevenue'] = 'C_DeliveryRevenue';
$report_include_modules['C_DeliveryRevenue'] = 'C_DeliveryRevenue';
$modInvisList[] = 'C_DeliveryRevenue';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Discount'] = 'J_Discount';
$beanFiles['J_Discount'] = 'modules/J_Discount/J_Discount.php';
$moduleList[] = 'J_Discount';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_DuplicationDetection'] = 'C_DuplicationDetection';
$beanFiles['C_DuplicationDetection'] = 'modules/C_DuplicationDetection/C_DuplicationDetection.php';
$moduleList[] = 'C_DuplicationDetection';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Feedback'] = 'J_Feedback';
$beanFiles['J_Feedback'] = 'modules/J_Feedback/J_Feedback.php';
$moduleList[] = 'J_Feedback';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_FieldHighlighter'] = 'C_FieldHighlighter';
$beanFiles['C_FieldHighlighter'] = 'modules/C_FieldHighlighter/C_FieldHighlighter.php';
$moduleList[] = 'C_FieldHighlighter';



 //WARNING: The contents of this file are auto-generated
//$beanList['C_Gradebook'] = 'C_Gradebook';
//$beanFiles['C_Gradebook'] = 'modules/C_Gradebook/C_Gradebook.php';
//$moduleList[] = 'C_Gradebook';



 //WARNING: The contents of this file are auto-generated
//$beanList['C_GradebookDetail'] = 'C_GradebookDetail';
//$beanFiles['C_GradebookDetail'] = 'modules/C_GradebookDetail/C_GradebookDetail.php';
//$modules_exempt_from_availability_check['C_GradebookDetail'] = 'C_GradebookDetail';
//$report_include_modules['C_GradebookDetail'] = 'C_GradebookDetail';
//$modInvisList[] = 'C_GradebookDetail';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_HelpTextConfig'] = 'C_HelpTextConfig';
$beanFiles['C_HelpTextConfig'] = 'modules/C_HelpTextConfig/C_HelpTextConfig.php';
$moduleList[] = 'C_HelpTextConfig';



$beanList['Holidays'] = 'Holiday';
$beanFiles['Holiday'] = 'modules/Holidays/Holiday.php';
//unset($modules_exempt_from_availability_check['Holiday']);
//unset($modInvisList['Holiday']);

$moduleList[] = 'J_Class';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Inventory'] = 'J_Inventory';
$beanFiles['J_Inventory'] = 'modules/J_Inventory/J_Inventory.php';
$moduleList[] = 'J_Inventory';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Inventorydetail'] = 'J_Inventorydetail';
$beanFiles['J_Inventorydetail'] = 'modules/J_Inventorydetail/J_Inventorydetail.php';
$modules_exempt_from_availability_check['J_Inventorydetail'] = 'J_Inventorydetail';
$report_include_modules['J_Inventorydetail'] = 'J_Inventorydetail';
$modInvisList[] = 'J_Inventorydetail';

 
 //WARNING: The contents of this file are auto-generated
//$beanList['C_Invoicelines'] = 'C_Invoicelines';
//$beanFiles['C_Invoicelines'] = 'modules/C_Invoicelines/C_Invoicelines.php';
//$moduleList[] = 'C_Invoicelines';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Invoices'] = 'C_Invoices';
$beanFiles['C_Invoices'] = 'modules/C_Invoices/C_Invoices.php';
$moduleList[] = 'C_Invoices';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Gradebook'] = 'J_Gradebook';
$beanFiles['J_Gradebook'] = 'modules/J_Gradebook/J_Gradebook.php';
$moduleList[] = 'J_Gradebook';
$beanList['J_GradebookConfig'] = 'J_GradebookConfig';
$beanFiles['J_GradebookConfig'] = 'modules/J_GradebookConfig/J_GradebookConfig.php';
$moduleList[] = 'J_GradebookConfig';
/*$modules_exempt_from_availability_check['J_GradebookConfig'] = 'J_GradebookConfig';
$report_include_modules['J_GradebookConfig'] = 'J_GradebookConfig';
$modInvisList[] = 'J_GradebookConfig'; */
$beanList['J_GradebookDetail'] = 'J_GradebookDetail';
$beanFiles['J_GradebookDetail'] = 'modules/J_GradebookDetail/J_GradebookDetail.php';
$moduleList[] = 'J_GradebookDetail';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_KeyboardSetting'] = 'C_KeyboardSetting';
$beanFiles['C_KeyboardSetting'] = 'modules/C_KeyboardSetting/C_KeyboardSetting.php';
$moduleList[] = 'C_KeyboardSetting';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Kindofcourse'] = 'J_Kindofcourse';
$beanFiles['J_Kindofcourse'] = 'modules/J_Kindofcourse/J_Kindofcourse.php';
$moduleList[] = 'J_Kindofcourse';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Marketingplan'] = 'J_Marketingplan';
$beanFiles['J_Marketingplan'] = 'modules/J_Marketingplan/J_Marketingplan.php';
$moduleList[] = 'J_Marketingplan';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Memberships'] = 'C_Memberships';
$beanFiles['C_Memberships'] = 'modules/C_Memberships/C_Memberships.php';
$moduleList[] = 'C_Memberships';



  /*$GLOBALS['moduleTabMap']['J_GradebookConfig'] = 'J_Gradebook';  
  $GLOBALS['moduleTabMap']['J_GradebookDetail'] = 'J_Gradebook';   */


 
 //WARNING: The contents of this file are auto-generated
//$beanList['C_Opplines'] = 'C_Opplines';
//$beanFiles['C_Opplines'] = 'modules/C_Opplines/C_Opplines.php';
//$moduleList[] = 'C_Opplines';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Packages'] = 'C_Packages';
$beanFiles['C_Packages'] = 'modules/C_Packages/C_Packages.php';
$moduleList[] = 'C_Packages';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Partnership'] = 'J_Partnership';
$beanFiles['J_Partnership'] = 'modules/J_Partnership/J_Partnership.php';
$moduleList[] = 'J_Partnership';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Payment'] = 'J_Payment';
$beanFiles['J_Payment'] = 'modules/J_Payment/J_Payment.php';
$moduleList[] = 'J_Payment';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_PaymentDetail'] = 'J_PaymentDetail';
$beanFiles['J_PaymentDetail'] = 'modules/J_PaymentDetail/J_PaymentDetail.php';
$moduleList[] = 'J_PaymentDetail';

 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Payments'] = 'C_Payments';
$beanFiles['C_Payments'] = 'modules/C_Payments/C_Payments.php';
$moduleList[] = 'C_Payments';


 
 //WARNING: The contents of this file are auto-generated
//$beanList['C_Printinglists'] = 'C_Printinglists';
//$beanFiles['C_Printinglists'] = 'modules/C_Printinglists/C_Printinglists.php';
//$moduleList[] = 'C_Printinglists';


 
 //WARNING: The contents of this file are auto-generated
//$beanList['C_Programs'] = 'C_Programs';
//$beanFiles['C_Programs'] = 'modules/C_Programs/C_Programs.php';
//$moduleList[] = 'C_Programs';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_PTResult'] = 'J_PTResult';
$beanFiles['J_PTResult'] = 'modules/J_PTResult/J_PTResult.php';
$moduleList[] = 'J_PTResult';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Refunds'] = 'C_Refunds';
$beanFiles['C_Refunds'] = 'modules/C_Refunds/C_Refunds.php';
$moduleList[] = 'C_Refunds';



 //WARNING: The contents of this file are auto-generated
$beanList['C_Reports'] = 'C_Reports';
$beanFiles['C_Reports'] = 'modules/C_Reports/C_Reports.php';
$modules_exempt_from_availability_check['C_Reports'] = 'C_Reports';
$report_include_modules['C_Reports'] = 'C_Reports';
$modInvisList[] = 'C_Reports';

 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Rooms'] = 'C_Rooms';
$beanFiles['C_Rooms'] = 'modules/C_Rooms/C_Rooms.php';
$moduleList[] = 'C_Rooms';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_School'] = 'J_School';
$beanFiles['J_School'] = 'modules/J_School/J_School.php';
$moduleList[] = 'J_School';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_SMS'] = 'C_SMS';
$beanFiles['C_SMS'] = 'modules/C_SMS/C_SMS.php';
$moduleList[] = 'C_SMS';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Sponsor'] = 'J_Sponsor';
$beanFiles['J_Sponsor'] = 'modules/J_Sponsor/J_Sponsor.php';
$modules_exempt_from_availability_check['J_Sponsor'] = 'J_Sponsor';
$report_include_modules['J_Sponsor'] = 'J_Sponsor';
$modInvisList[] = 'J_Sponsor';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Sponsors'] = 'C_Sponsors';
$beanFiles['C_Sponsors'] = 'modules/C_Sponsors/C_Sponsors.php';
$moduleList[] = 'C_Sponsors';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_StudentSituations'] = 'J_StudentSituations';
$beanFiles['J_StudentSituations'] = 'modules/J_StudentSituations/J_StudentSituations.php';
$moduleList[] = 'J_StudentSituations';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Targetconfig'] = 'J_Targetconfig';
$beanFiles['J_Targetconfig'] = 'modules/J_Targetconfig/J_Targetconfig.php';
$moduleList[] = 'J_Targetconfig';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Teachers'] = 'C_Teachers';
$beanFiles['C_Teachers'] = 'modules/C_Teachers/C_Teachers.php';
$moduleList[] = 'C_Teachers';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Teachercontract'] = 'J_Teachercontract';
$beanFiles['J_Teachercontract'] = 'modules/J_Teachercontract/J_Teachercontract.php';
$moduleList[] = 'J_Teachercontract';


 
 //WARNING: The contents of this file are auto-generated
$beanList['c_Timekeeping'] = 'c_Timekeeping';
$beanFiles['c_Timekeeping'] = 'modules/c_Timekeeping/c_Timekeeping.php';
$modules_exempt_from_availability_check['c_Timekeeping'] = 'c_Timekeeping';
$report_include_modules['c_Timekeeping'] = 'c_Timekeeping';
$modInvisList[] = 'c_Timekeeping';


 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Timesheet'] = 'C_Timesheet';
$beanFiles['C_Timesheet'] = 'modules/C_Timesheet/C_Timesheet.php';
$moduleList[] = 'C_Timesheet';



 //WARNING: The contents of this file are auto-generated
//$beanList['C_Vouchers'] = 'C_Vouchers';
//$beanFiles['C_Vouchers'] = 'modules/C_Vouchers/C_Vouchers.php';
//$moduleList[] = 'C_Vouchers';


 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Voucher'] = 'J_Voucher';
$beanFiles['J_Voucher'] = 'modules/J_Voucher/J_Voucher.php';
$moduleList[] = 'J_Voucher';


?>