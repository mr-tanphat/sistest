<?php
   $app_list_strings['moduleList']['Holidays'] = 'Holidays';
?>
