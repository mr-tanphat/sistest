<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_classes_c_teachers_1MetaData.php');

?>