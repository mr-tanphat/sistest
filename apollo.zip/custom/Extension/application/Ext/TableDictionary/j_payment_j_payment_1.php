<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_payment_j_payment_1MetaData.php');

?>