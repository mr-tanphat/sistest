<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/meetings_j_ptresult_1MetaData.php');

?>