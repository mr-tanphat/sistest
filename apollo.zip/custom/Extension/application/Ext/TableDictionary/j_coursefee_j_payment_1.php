<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_coursefee_j_payment_1MetaData.php');

?>