<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_sponsors_c_payments_1MetaData.php');

?>