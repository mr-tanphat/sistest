<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_j_payment_1MetaData.php');

?>