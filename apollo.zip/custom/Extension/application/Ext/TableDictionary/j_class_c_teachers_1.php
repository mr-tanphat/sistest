<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_class_c_teachers_1MetaData.php');

?>