<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_partnership_j_payment_1MetaData.php');

?>