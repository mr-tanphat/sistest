<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_invoices_opportunities_1MetaData.php');

?>