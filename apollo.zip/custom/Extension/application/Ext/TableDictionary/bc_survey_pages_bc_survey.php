<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/bc_survey_pages_bc_surveyMetaData.php');

?>