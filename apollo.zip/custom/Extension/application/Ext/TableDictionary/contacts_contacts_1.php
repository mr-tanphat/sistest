<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_contacts_1MetaData.php');

?>