<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/contacts_c_payments_2MetaData.php');

?>