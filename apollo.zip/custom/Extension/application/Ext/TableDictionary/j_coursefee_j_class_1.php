<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/j_coursefee_j_class_1MetaData.php');

?>