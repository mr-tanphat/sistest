<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c_contacts_contacts_1MetaData.php');

?>