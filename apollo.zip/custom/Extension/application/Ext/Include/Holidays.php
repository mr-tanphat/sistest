<?php
$beanList['Holidays'] = 'Holiday';
$beanFiles['Holiday'] = 'modules/Holidays/Holiday.php';
//unset($modules_exempt_from_availability_check['Holiday']);
//unset($modInvisList['Holiday']);

$moduleList[] = 'J_Class';
?>
