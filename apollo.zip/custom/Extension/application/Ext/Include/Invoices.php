<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Invoices'] = 'C_Invoices';
$beanFiles['C_Invoices'] = 'modules/C_Invoices/C_Invoices.php';
$moduleList[] = 'C_Invoices';

?>