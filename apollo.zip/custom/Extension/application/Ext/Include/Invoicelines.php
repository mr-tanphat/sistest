<?php 
 //WARNING: The contents of this file are auto-generated
//$beanList['C_Invoicelines'] = 'C_Invoicelines';
//$beanFiles['C_Invoicelines'] = 'modules/C_Invoicelines/C_Invoicelines.php';
//$moduleList[] = 'C_Invoicelines';

?>