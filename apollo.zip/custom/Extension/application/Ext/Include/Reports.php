<?php
 //WARNING: The contents of this file are auto-generated
$beanList['C_Reports'] = 'C_Reports';
$beanFiles['C_Reports'] = 'modules/C_Reports/C_Reports.php';
$modules_exempt_from_availability_check['C_Reports'] = 'C_Reports';
$report_include_modules['C_Reports'] = 'C_Reports';
$modInvisList[] = 'C_Reports';
?>