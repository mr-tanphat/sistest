<?php 
 //WARNING: The contents of this file are auto-generated
//$beanList['C_Programs'] = 'C_Programs';
//$beanFiles['C_Programs'] = 'modules/C_Programs/C_Programs.php';
//$moduleList[] = 'C_Programs';

?>