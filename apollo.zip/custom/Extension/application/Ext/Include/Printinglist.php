<?php 
 //WARNING: The contents of this file are auto-generated
//$beanList['C_Printinglists'] = 'C_Printinglists';
//$beanFiles['C_Printinglists'] = 'modules/C_Printinglists/C_Printinglists.php';
//$moduleList[] = 'C_Printinglists';

?>