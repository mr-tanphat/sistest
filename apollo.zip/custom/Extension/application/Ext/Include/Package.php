<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Packages'] = 'C_Packages';
$beanFiles['C_Packages'] = 'modules/C_Packages/C_Packages.php';
$moduleList[] = 'C_Packages';

?>