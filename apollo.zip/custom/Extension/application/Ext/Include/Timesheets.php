<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Timesheet'] = 'C_Timesheet';
$beanFiles['C_Timesheet'] = 'modules/C_Timesheet/C_Timesheet.php';
$moduleList[] = 'C_Timesheet';

?>