<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_KeyboardSetting'] = 'C_KeyboardSetting';
$beanFiles['C_KeyboardSetting'] = 'modules/C_KeyboardSetting/C_KeyboardSetting.php';
$moduleList[] = 'C_KeyboardSetting';

?>