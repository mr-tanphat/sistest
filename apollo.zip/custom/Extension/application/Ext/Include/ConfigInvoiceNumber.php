<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_ConfigInvoiceNo'] = 'J_ConfigInvoiceNo';
$beanFiles['J_ConfigInvoiceNo'] = 'modules/J_ConfigInvoiceNo/J_ConfigInvoiceNo.php';
$moduleList[] = 'J_ConfigInvoiceNo';

?>