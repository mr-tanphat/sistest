<?php
 //WARNING: The contents of this file are auto-generated
//$beanList['C_GradebookDetail'] = 'C_GradebookDetail';
//$beanFiles['C_GradebookDetail'] = 'modules/C_GradebookDetail/C_GradebookDetail.php';
//$modules_exempt_from_availability_check['C_GradebookDetail'] = 'C_GradebookDetail';
//$report_include_modules['C_GradebookDetail'] = 'C_GradebookDetail';
//$modInvisList[] = 'C_GradebookDetail';

?>