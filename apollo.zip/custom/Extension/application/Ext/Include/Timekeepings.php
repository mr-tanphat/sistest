<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['c_Timekeeping'] = 'c_Timekeeping';
$beanFiles['c_Timekeeping'] = 'modules/c_Timekeeping/c_Timekeeping.php';
$modules_exempt_from_availability_check['c_Timekeeping'] = 'c_Timekeeping';
$report_include_modules['c_Timekeeping'] = 'c_Timekeeping';
$modInvisList[] = 'c_Timekeeping';

?>