<?php
 //WARNING: The contents of this file are auto-generated
//$beanList['C_Vouchers'] = 'C_Vouchers';
//$beanFiles['C_Vouchers'] = 'modules/C_Vouchers/C_Vouchers.php';
//$moduleList[] = 'C_Vouchers';

?>