<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Commission'] = 'C_Commission';
$beanFiles['C_Commission'] = 'modules/C_Commission/C_Commission.php';
$modules_exempt_from_availability_check['C_Commission'] = 'C_Commission';
$report_include_modules['C_Commission'] = 'C_Commission';
$modInvisList[] = 'C_Commission';

?>