<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Discount'] = 'J_Discount';
$beanFiles['J_Discount'] = 'modules/J_Discount/J_Discount.php';
$moduleList[] = 'J_Discount';

?>