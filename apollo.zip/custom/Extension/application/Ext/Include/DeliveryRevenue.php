<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_DeliveryRevenue'] = 'C_DeliveryRevenue';
$beanFiles['C_DeliveryRevenue'] = 'modules/C_DeliveryRevenue/C_DeliveryRevenue.php';
$modules_exempt_from_availability_check['C_DeliveryRevenue'] = 'C_DeliveryRevenue';
$report_include_modules['C_DeliveryRevenue'] = 'C_DeliveryRevenue';
$modInvisList[] = 'C_DeliveryRevenue';

?>