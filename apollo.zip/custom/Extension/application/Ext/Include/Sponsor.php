<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Sponsor'] = 'J_Sponsor';
$beanFiles['J_Sponsor'] = 'modules/J_Sponsor/J_Sponsor.php';
$modules_exempt_from_availability_check['J_Sponsor'] = 'J_Sponsor';
$report_include_modules['J_Sponsor'] = 'J_Sponsor';
$modInvisList[] = 'J_Sponsor';

?>