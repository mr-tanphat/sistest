<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Inventorydetail'] = 'J_Inventorydetail';
$beanFiles['J_Inventorydetail'] = 'modules/J_Inventorydetail/J_Inventorydetail.php';
$modules_exempt_from_availability_check['J_Inventorydetail'] = 'J_Inventorydetail';
$report_include_modules['J_Inventorydetail'] = 'J_Inventorydetail';
$modInvisList[] = 'J_Inventorydetail';
?>