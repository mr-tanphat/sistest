<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_ConfigID'] = 'C_ConfigID';
$beanFiles['C_ConfigID'] = 'modules/C_ConfigID/C_ConfigID.php';
$modules_exempt_from_availability_check['C_ConfigID'] = 'C_ConfigID';
$report_include_modules['C_ConfigID'] = 'C_ConfigID';
$modInvisList[] = 'C_ConfigID';

?>