<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Sponsors'] = 'C_Sponsors';
$beanFiles['C_Sponsors'] = 'modules/C_Sponsors/C_Sponsors.php';
$moduleList[] = 'C_Sponsors';

?>