<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Rooms'] = 'C_Rooms';
$beanFiles['C_Rooms'] = 'modules/C_Rooms/C_Rooms.php';
$moduleList[] = 'C_Rooms';

?>