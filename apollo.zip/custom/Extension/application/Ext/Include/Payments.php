<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Payments'] = 'C_Payments';
$beanFiles['C_Payments'] = 'modules/C_Payments/C_Payments.php';
$moduleList[] = 'C_Payments';

?>