<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Contacts'] = 'C_Contacts';
$beanFiles['C_Contacts'] = 'modules/C_Contacts/C_Contacts.php';
$moduleList[] = 'C_Contacts';

?>