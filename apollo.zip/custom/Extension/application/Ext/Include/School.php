<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_School'] = 'J_School';
$beanFiles['J_School'] = 'modules/J_School/J_School.php';
$moduleList[] = 'J_School';

?>