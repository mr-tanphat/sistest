<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Partnership'] = 'J_Partnership';
$beanFiles['J_Partnership'] = 'modules/J_Partnership/J_Partnership.php';
$moduleList[] = 'J_Partnership';

?>