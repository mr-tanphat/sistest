<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Feedback'] = 'J_Feedback';
$beanFiles['J_Feedback'] = 'modules/J_Feedback/J_Feedback.php';
$moduleList[] = 'J_Feedback';

?>