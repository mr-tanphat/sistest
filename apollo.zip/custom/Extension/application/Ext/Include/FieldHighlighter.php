<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_FieldHighlighter'] = 'C_FieldHighlighter';
$beanFiles['C_FieldHighlighter'] = 'modules/C_FieldHighlighter/C_FieldHighlighter.php';
$moduleList[] = 'C_FieldHighlighter';

?>