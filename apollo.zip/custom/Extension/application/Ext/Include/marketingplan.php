<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Marketingplan'] = 'J_Marketingplan';
$beanFiles['J_Marketingplan'] = 'modules/J_Marketingplan/J_Marketingplan.php';
$moduleList[] = 'J_Marketingplan';

?>