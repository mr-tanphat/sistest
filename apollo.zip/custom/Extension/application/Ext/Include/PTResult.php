<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_PTResult'] = 'J_PTResult';
$beanFiles['J_PTResult'] = 'modules/J_PTResult/J_PTResult.php';
$moduleList[] = 'J_PTResult';

?>