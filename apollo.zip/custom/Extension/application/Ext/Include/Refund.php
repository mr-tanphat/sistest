<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Refunds'] = 'C_Refunds';
$beanFiles['C_Refunds'] = 'modules/C_Refunds/C_Refunds.php';
$moduleList[] = 'C_Refunds';

?>