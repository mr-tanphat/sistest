<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Memberships'] = 'C_Memberships';
$beanFiles['C_Memberships'] = 'modules/C_Memberships/C_Memberships.php';
$moduleList[] = 'C_Memberships';

?>