<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Teachers'] = 'C_Teachers';
$beanFiles['C_Teachers'] = 'modules/C_Teachers/C_Teachers.php';
$moduleList[] = 'C_Teachers';

?>