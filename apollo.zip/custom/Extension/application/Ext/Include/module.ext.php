<?php
  /*$GLOBALS['moduleTabMap']['J_GradebookConfig'] = 'J_Gradebook';  
  $GLOBALS['moduleTabMap']['J_GradebookDetail'] = 'J_Gradebook';   */
?>
