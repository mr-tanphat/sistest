<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Targetconfig'] = 'J_Targetconfig';
$beanFiles['J_Targetconfig'] = 'modules/J_Targetconfig/J_Targetconfig.php';
$moduleList[] = 'J_Targetconfig';

?>