<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_PaymentDetail'] = 'J_PaymentDetail';
$beanFiles['J_PaymentDetail'] = 'modules/J_PaymentDetail/J_PaymentDetail.php';
$moduleList[] = 'J_PaymentDetail';
?>