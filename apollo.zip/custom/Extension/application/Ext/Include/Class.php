<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Class'] = 'J_Class';
$beanFiles['J_Class'] = 'modules/J_Class/J_Class.php';
$moduleList[] = 'J_Class';

?>