<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_StudentSituations'] = 'J_StudentSituations';
$beanFiles['J_StudentSituations'] = 'modules/J_StudentSituations/J_StudentSituations.php';
$moduleList[] = 'J_StudentSituations';

?>