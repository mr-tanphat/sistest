<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Voucher'] = 'J_Voucher';
$beanFiles['J_Voucher'] = 'modules/J_Voucher/J_Voucher.php';
$moduleList[] = 'J_Voucher';

?>