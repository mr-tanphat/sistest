<?php 
 //WARNING: The contents of this file are auto-generated
//$beanList['C_Opplines'] = 'C_Opplines';
//$beanFiles['C_Opplines'] = 'modules/C_Opplines/C_Opplines.php';
//$moduleList[] = 'C_Opplines';

?>