<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Attendance'] = 'C_Attendance';
$beanFiles['C_Attendance'] = 'modules/C_Attendance/C_Attendance.php';
$moduleList[] = 'C_Attendance';

?>