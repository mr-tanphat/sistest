<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Coursefee'] = 'J_Coursefee';
$beanFiles['J_Coursefee'] = 'modules/J_Coursefee/J_Coursefee.php';
$moduleList[] = 'J_Coursefee';

?>