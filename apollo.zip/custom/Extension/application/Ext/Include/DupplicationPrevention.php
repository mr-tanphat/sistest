<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_DuplicationDetection'] = 'C_DuplicationDetection';
$beanFiles['C_DuplicationDetection'] = 'modules/C_DuplicationDetection/C_DuplicationDetection.php';
$moduleList[] = 'C_DuplicationDetection';

?>