<?php
 //WARNING: The contents of this file are auto-generated
//$beanList['C_Gradebook'] = 'C_Gradebook';
//$beanFiles['C_Gradebook'] = 'modules/C_Gradebook/C_Gradebook.php';
//$moduleList[] = 'C_Gradebook';

?>