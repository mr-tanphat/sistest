<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Kindofcourse'] = 'J_Kindofcourse';
$beanFiles['J_Kindofcourse'] = 'modules/J_Kindofcourse/J_Kindofcourse.php';
$moduleList[] = 'J_Kindofcourse';

?>