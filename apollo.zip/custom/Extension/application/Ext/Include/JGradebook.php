<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Gradebook'] = 'J_Gradebook';
$beanFiles['J_Gradebook'] = 'modules/J_Gradebook/J_Gradebook.php';
$moduleList[] = 'J_Gradebook';
$beanList['J_GradebookConfig'] = 'J_GradebookConfig';
$beanFiles['J_GradebookConfig'] = 'modules/J_GradebookConfig/J_GradebookConfig.php';
$moduleList[] = 'J_GradebookConfig';
/*$modules_exempt_from_availability_check['J_GradebookConfig'] = 'J_GradebookConfig';
$report_include_modules['J_GradebookConfig'] = 'J_GradebookConfig';
$modInvisList[] = 'J_GradebookConfig'; */
$beanList['J_GradebookDetail'] = 'J_GradebookDetail';
$beanFiles['J_GradebookDetail'] = 'modules/J_GradebookDetail/J_GradebookDetail.php';
$moduleList[] = 'J_GradebookDetail';

?>