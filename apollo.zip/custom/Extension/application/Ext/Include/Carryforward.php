<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_Carryforward'] = 'C_Carryforward';
$beanFiles['C_Carryforward'] = 'modules/C_Carryforward/C_Carryforward.php';
$modules_exempt_from_availability_check['C_Carryforward'] = 'C_Carryforward';
$report_include_modules['C_Carryforward'] = 'C_Carryforward';
$modInvisList[] = 'C_Carryforward';

?>