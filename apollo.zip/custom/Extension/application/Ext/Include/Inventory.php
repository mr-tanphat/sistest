<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Inventory'] = 'J_Inventory';
$beanFiles['J_Inventory'] = 'modules/J_Inventory/J_Inventory.php';
$moduleList[] = 'J_Inventory';

?>