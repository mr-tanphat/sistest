<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_HelpTextConfig'] = 'C_HelpTextConfig';
$beanFiles['C_HelpTextConfig'] = 'modules/C_HelpTextConfig/C_HelpTextConfig.php';
$moduleList[] = 'C_HelpTextConfig';

?>