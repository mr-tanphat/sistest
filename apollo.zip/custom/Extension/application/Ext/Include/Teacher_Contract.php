<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Teachercontract'] = 'J_Teachercontract';
$beanFiles['J_Teachercontract'] = 'modules/J_Teachercontract/J_Teachercontract.php';
$moduleList[] = 'J_Teachercontract';

?>