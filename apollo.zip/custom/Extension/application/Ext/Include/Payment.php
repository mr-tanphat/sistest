<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['J_Payment'] = 'J_Payment';
$beanFiles['J_Payment'] = 'modules/J_Payment/J_Payment.php';
$moduleList[] = 'J_Payment';

?>