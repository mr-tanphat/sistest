<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C_SMS'] = 'C_SMS';
$beanFiles['C_SMS'] = 'modules/C_SMS/C_SMS.php';
$moduleList[] = 'C_SMS';

?>