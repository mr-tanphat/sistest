<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['bc_submission_data'] = 'bc_submission_data';
$beanFiles['bc_submission_data'] = 'modules/bc_submission_data/bc_submission_data.php';
$modules_exempt_from_availability_check['bc_submission_data'] = 'bc_submission_data';
$report_include_modules['bc_submission_data'] = 'bc_submission_data';
$modInvisList[] = 'bc_submission_data';
$beanList['bc_survey_submission'] = 'bc_survey_submission';
$beanFiles['bc_survey_submission'] = 'modules/bc_survey_submission/bc_survey_submission.php';
$modules_exempt_from_availability_check['bc_survey_submission'] = 'bc_survey_submission';
$report_include_modules['bc_survey_submission'] = 'bc_survey_submission';
$modInvisList[] = 'bc_survey_submission';
$beanList['bc_survey_template'] = 'bc_survey_template';
$beanFiles['bc_survey_template'] = 'modules/bc_survey_template/bc_survey_template.php';
$moduleList[] = 'bc_survey_template';
$beanList['bc_survey'] = 'bc_survey';
$beanFiles['bc_survey'] = 'modules/bc_survey/bc_survey.php';
$moduleList[] = 'bc_survey';
$beanList['bc_survey_questions'] = 'bc_survey_questions';
$beanFiles['bc_survey_questions'] = 'modules/bc_survey_questions/bc_survey_questions.php';
$modules_exempt_from_availability_check['bc_survey_questions'] = 'bc_survey_questions';
$report_include_modules['bc_survey_questions'] = 'bc_survey_questions';
$modInvisList[] = 'bc_survey_questions';
$beanList['bc_survey_pages'] = 'bc_survey_pages';
$beanFiles['bc_survey_pages'] = 'modules/bc_survey_pages/bc_survey_pages.php';
$modules_exempt_from_availability_check['bc_survey_pages'] = 'bc_survey_pages';
$report_include_modules['bc_survey_pages'] = 'bc_survey_pages';
$modInvisList[] = 'bc_survey_pages';
$beanList['bc_survey_answers'] = 'bc_survey_answers';
$beanFiles['bc_survey_answers'] = 'modules/bc_survey_answers/bc_survey_answers.php';
$modules_exempt_from_availability_check['bc_survey_answers'] = 'bc_survey_answers';
$report_include_modules['bc_survey_answers'] = 'bc_survey_answers';
$modInvisList[] = 'bc_survey_answers';
$beanList['bc_survey_automizer'] = 'bc_survey_automizer';
$beanFiles['bc_survey_automizer'] = 'modules/bc_survey_automizer/bc_survey_automizer.php';
$moduleList[] = 'bc_survey_automizer';
$beanList['bc_automizer_condition'] = 'bc_automizer_condition';
$beanFiles['bc_automizer_condition'] = 'modules/bc_automizer_condition/bc_automizer_condition.php';
$modules_exempt_from_availability_check['bc_automizer_condition'] = 'bc_automizer_condition';
$report_include_modules['bc_automizer_condition'] = 'bc_automizer_condition';
$modInvisList[] = 'bc_automizer_condition';
$beanList['bc_automizer_actions'] = 'bc_automizer_actions';
$beanFiles['bc_automizer_actions'] = 'modules/bc_automizer_actions/bc_automizer_actions.php';
$modules_exempt_from_availability_check['bc_automizer_actions'] = 'bc_automizer_actions';
$report_include_modules['bc_automizer_actions'] = 'bc_automizer_actions';
$modInvisList[] = 'bc_automizer_actions';

?>