<?php
 // created: 2014-07-15 14:43:15
$layout_defs["C_Classes"]["subpanel_setup"]['c_classes_c_teachers_1'] = array (
  'order' => 100,
  'module' => 'C_Teachers',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_C_CLASSES_C_TEACHERS_1_FROM_C_TEACHERS_TITLE',
  'get_subpanel_data' => 'c_classes_c_teachers_1',
);
