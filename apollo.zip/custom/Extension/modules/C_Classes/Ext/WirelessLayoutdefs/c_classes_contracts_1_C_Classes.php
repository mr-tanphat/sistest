<?php
 // created: 2014-12-02 16:49:45
$layout_defs["C_Classes"]["subpanel_setup"]['c_classes_contracts_1'] = array (
  'order' => 100,
  'module' => 'Contracts',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_C_CLASSES_CONTRACTS_1_FROM_CONTRACTS_TITLE',
  'get_subpanel_data' => 'c_classes_contracts_1',
);
