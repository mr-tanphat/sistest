<?php
 // created: 2014-07-15 14:40:52
$layout_defs["C_Classes"]["subpanel_setup"]['c_classes_contacts_1'] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_C_CLASSES_CONTACTS_1_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'c_classes_contacts_1',
);
