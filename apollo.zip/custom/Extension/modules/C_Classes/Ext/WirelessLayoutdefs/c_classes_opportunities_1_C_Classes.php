<?php
 // created: 2014-11-12 02:35:22
$layout_defs["C_Classes"]["subpanel_setup"]['c_classes_opportunities_1'] = array (
  'order' => 100,
  'module' => 'Opportunities',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_C_CLASSES_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE',
  'get_subpanel_data' => 'c_classes_opportunities_1',
);
