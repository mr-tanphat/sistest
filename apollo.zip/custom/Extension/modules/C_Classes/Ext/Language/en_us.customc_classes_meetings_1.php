<?php
$mod_strings['LBL_MEETING'] = 'Sessions';
