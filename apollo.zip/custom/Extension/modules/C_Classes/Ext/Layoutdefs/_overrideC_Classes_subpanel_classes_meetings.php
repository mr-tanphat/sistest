<?php
//auto-generated file DO NOT EDIT
$layout_defs['C_Classes']['subpanel_setup']['classes_meetings']['override_subpanel_name'] = 'C_Classes_subpanel_classes_meetings';
?>