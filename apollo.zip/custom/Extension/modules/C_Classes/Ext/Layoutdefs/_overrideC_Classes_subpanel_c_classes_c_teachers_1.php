<?php
//auto-generated file DO NOT EDIT
$layout_defs['C_Classes']['subpanel_setup']['c_classes_c_teachers_1']['override_subpanel_name'] = 'C_Classes_subpanel_c_classes_c_teachers_1';
?>