<?php
// created: 2014-07-15 14:40:52
$dictionary["C_Classes"]["fields"]["c_classes_contacts_1"] = array (
  'name' => 'c_classes_contacts_1',
  'type' => 'link',
  'relationship' => 'c_classes_contacts_1',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_C_CLASSES_CONTACTS_1_FROM_CONTACTS_TITLE',
  'id_name' => 'c_classes_contacts_1contacts_idb',
);
