<?php
// created: 2014-07-15 14:47:51
$dictionary["C_Classes"]["fields"]["c_classes_c_rooms_1"] = array (
  'name' => 'c_classes_c_rooms_1',
  'type' => 'link',
  'relationship' => 'c_classes_c_rooms_1',
  'source' => 'non-db',
  'module' => 'C_Rooms',
  'bean_name' => 'C_Rooms',
  'vname' => 'LBL_C_CLASSES_C_ROOMS_1_FROM_C_ROOMS_TITLE',
  'id_name' => 'c_classes_c_rooms_1c_rooms_idb',
);
