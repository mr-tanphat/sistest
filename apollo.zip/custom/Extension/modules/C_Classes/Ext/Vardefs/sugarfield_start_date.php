<?php
 // created: 2015-07-02 10:04:07
$dictionary['C_Classes']['fields']['start_date']['display_default']='';

 ?>