<?php
 // created: 2014-08-12 12:09:11
$dictionary['C_Classes']['fields']['description']['comments']='Full text of the note';
$dictionary['C_Classes']['fields']['description']['merge_filter']='disabled';
$dictionary['C_Classes']['fields']['description']['calculated']=false;
$dictionary['C_Classes']['fields']['description']['rows']='4';
$dictionary['C_Classes']['fields']['description']['cols']='66';

 ?>