<?php
// created: 2014-11-12 02:35:22
$dictionary["C_Classes"]["fields"]["c_classes_opportunities_1"] = array (
  'name' => 'c_classes_opportunities_1',
  'type' => 'link',
  'relationship' => 'c_classes_opportunities_1',
  'source' => 'non-db',
  'module' => 'Opportunities',
  'bean_name' => 'Opportunity',
  'vname' => 'LBL_C_CLASSES_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'c_classes_opportunities_1opportunities_idb',
);
