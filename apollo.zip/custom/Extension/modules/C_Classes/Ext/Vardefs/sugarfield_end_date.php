<?php
 // created: 2014-06-27 16:26:48
$dictionary['C_Classes']['fields']['end_date']['calculated']=false;

 ?>