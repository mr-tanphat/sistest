<?php
// created: 2014-12-02 16:49:45
$dictionary["C_Classes"]["fields"]["c_classes_contracts_1"] = array (
  'name' => 'c_classes_contracts_1',
  'type' => 'link',
  'relationship' => 'c_classes_contracts_1',
  'source' => 'non-db',
  'module' => 'Contracts',
  'bean_name' => 'Contract',
  'vname' => 'LBL_C_CLASSES_CONTRACTS_1_FROM_CONTRACTS_TITLE',
  'id_name' => 'c_classes_contracts_1contracts_idb',
);
