<?php
// created: 2014-07-15 14:43:15
$dictionary["C_Classes"]["fields"]["c_classes_c_teachers_1"] = array (
  'name' => 'c_classes_c_teachers_1',
  'type' => 'link',
  'relationship' => 'c_classes_c_teachers_1',
  'source' => 'non-db',
  'module' => 'C_Teachers',
  'bean_name' => 'C_Teachers',
  'vname' => 'LBL_C_CLASSES_C_TEACHERS_1_FROM_C_TEACHERS_TITLE',
  'id_name' => 'c_classes_c_teachers_1c_teachers_idb',
);
