<?php
//auto-generated file DO NOT EDIT
$layout_defs['Accounts']['subpanel_setup']['contracts']['override_subpanel_name'] = 'Account_subpanel_contracts';
?>