<?php
 // created: 2014-04-12 00:29:43
$layout_defs["Accounts"]["subpanel_setup"]['accounts_c_invoices_1'] = array (
  'order' => 100,
  'module' => 'C_Invoices',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_ACCOUNTS_C_INVOICES_1_FROM_C_INVOICES_TITLE',
  'get_subpanel_data' => 'accounts_c_invoices_1',
);
