<?php
// created: 2014-04-12 00:31:10
$dictionary["Account"]["fields"]["accounts_c_payments_1"] = array (
  'name' => 'accounts_c_payments_1',
  'type' => 'link',
  'relationship' => 'accounts_c_payments_1',
  'source' => 'non-db',
  'module' => 'C_Payments',
  'bean_name' => 'C_Payments',
  'vname' => 'LBL_ACCOUNTS_C_PAYMENTS_1_FROM_ACCOUNTS_TITLE',
  'id_name' => 'accounts_c_payments_1accounts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
