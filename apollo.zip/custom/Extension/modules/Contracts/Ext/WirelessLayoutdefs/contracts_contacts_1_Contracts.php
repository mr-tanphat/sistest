<?php
 // created: 2014-07-23 08:54:18
$layout_defs["Contracts"]["subpanel_setup"]['contracts_contacts_1'] = array (
  'order' => 100,
  'module' => 'Contacts',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CONTRACTS_CONTACTS_1_FROM_CONTACTS_TITLE',
  'get_subpanel_data' => 'contracts_contacts_1',
);
