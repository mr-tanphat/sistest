<?php
 // created: 2014-12-02 16:49:45
$layout_defs["Contracts"]["subpanel_setup"]['c_classes_contracts_1'] = array (
  'order' => 100,
  'module' => 'C_Classes',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_C_CLASSES_CONTRACTS_1_FROM_C_CLASSES_TITLE',
  'get_subpanel_data' => 'c_classes_contracts_1',
);
