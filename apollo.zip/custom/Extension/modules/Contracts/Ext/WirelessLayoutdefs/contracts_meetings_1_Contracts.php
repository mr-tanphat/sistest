<?php
 // created: 2014-12-02 16:32:02
$layout_defs["Contracts"]["subpanel_setup"]['contracts_meetings_1'] = array (
  'order' => 100,
  'module' => 'Meetings',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CONTRACTS_MEETINGS_1_FROM_MEETINGS_TITLE',
  'get_subpanel_data' => 'contracts_meetings_1',
);
