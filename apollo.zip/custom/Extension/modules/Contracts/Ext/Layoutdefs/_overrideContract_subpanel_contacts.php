<?php
//auto-generated file DO NOT EDIT
$layout_defs['Contracts']['subpanel_setup']['contacts']['override_subpanel_name'] = 'Contract_subpanel_contacts';
?>