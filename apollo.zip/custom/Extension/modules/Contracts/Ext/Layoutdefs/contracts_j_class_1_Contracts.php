<?php
 // created: 2016-11-25 10:58:12
$layout_defs["Contracts"]["subpanel_setup"]['contracts_j_class_1'] = array (
  'order' => 100,
  'module' => 'J_Class',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CONTRACTS_J_CLASS_1_FROM_J_CLASS_TITLE',
  'get_subpanel_data' => 'contracts_j_class_1',
  'top_buttons' =>
  array (
//    0 =>
//    array (
//      'widget_class' => 'SubPanelTopButtonQuickCreate',
//    ),
//    1 =>
//    array (
//      'widget_class' => 'SubPanelTopSelectButton',
//      'mode' => 'MultiSelect',
//    ),
  ),
);
