<?php
//auto-generated file DO NOT EDIT
$layout_defs['Contracts']['subpanel_setup']['contracts_contacts_1']['override_subpanel_name'] = 'Contract_subpanel_contracts_contacts_1';
?>