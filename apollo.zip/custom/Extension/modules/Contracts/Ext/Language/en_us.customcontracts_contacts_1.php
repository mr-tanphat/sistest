<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_CONTRACTS_CONTACTS_1_FROM_CONTACTS_TITLE'] = 'Student In Class';
$mod_strings['LBL_DELIVERY_CONTRACT'] = 'Contract Delivery';
