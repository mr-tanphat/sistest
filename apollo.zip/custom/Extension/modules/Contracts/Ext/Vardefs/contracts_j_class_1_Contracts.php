<?php
// created: 2016-11-25 10:58:12
$dictionary["Contract"]["fields"]["contracts_j_class_1"] = array (
  'name' => 'contracts_j_class_1',
  'type' => 'link',
  'relationship' => 'contracts_j_class_1',
  'source' => 'non-db',
  'module' => 'J_Class',
  'bean_name' => 'J_Class',
  'vname' => 'LBL_CONTRACTS_J_CLASS_1_FROM_J_CLASS_TITLE',
  'id_name' => 'contracts_j_class_1j_class_idb',
);
