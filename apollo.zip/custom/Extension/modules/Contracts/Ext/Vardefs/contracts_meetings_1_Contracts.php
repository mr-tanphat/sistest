<?php
// created: 2014-12-02 16:32:02
$dictionary["Contract"]["fields"]["contracts_meetings_1"] = array (
  'name' => 'contracts_meetings_1',
  'type' => 'link',
  'relationship' => 'contracts_meetings_1',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'vname' => 'LBL_CONTRACTS_MEETINGS_1_FROM_MEETINGS_TITLE',
  'id_name' => 'contracts_meetings_1meetings_idb',
);
