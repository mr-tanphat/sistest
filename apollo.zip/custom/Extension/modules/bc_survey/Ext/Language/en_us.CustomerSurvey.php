<?php
/**
 *
 * LICENSE: The contents of this file are subject to the license agreement ("License") which is included
 * in the installation package (LICENSE.txt). By installing or using this file, you have unconditionally
 * agreed to the terms and conditions of the License, and you may not use this file except in compliance
 * with the License.
 *
 * @author     Original Author Biztech Co.
 */
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_BC_SURVEY_SUBMISSION_BC_SURVEY_FROM_BC_SURVEY_SUBMISSION_TITLE'] = 'Survey Submission';
$mod_strings['LBL_BC_SURVEY_BC_SURVEY_QUESTIONS_FROM_BC_SURVEY_QUESTIONS_TITLE'] = 'Survey Questions';
$mod_strings['LBL_BC_SURVEY_BC_SURVEY_TEMPLATE_FROM_BC_SURVEY_TEMPLATE_TITLE'] = 'Survey Template';
$mod_strings['LBL_BC_SURVEY_ACCOUNTS_FROM_ACCOUNTS_TITLE'] = 'Accounts';
$mod_strings['LBL_BC_SURVEY_CONTACTS_FROM_CONTACTS_TITLE'] = 'Contacts';
$mod_strings['LBL_BC_SURVEY_LEADS_FROM_LEADS_TITLE'] = 'Leads';
$mod_strings['LBL_BC_SURVEY_USERS_FROM_USERS_TITLE'] = 'Users';
$mod_strings['LBL_BC_SURVEY_PROSPECTS_FROM_PROSPECTS_TITLE'] = 'Targets';
$mod_strings['LBL_BC_SURVEY_PAGES_BC_SURVEY_FROM_BC_SURVEY_PAGES_TITLE'] = 'Survey Pages';
