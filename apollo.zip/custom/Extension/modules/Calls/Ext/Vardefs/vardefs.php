<?php
$dictionary["Call"]["fields"]["call_type"] = array (
    'name' => 'call_type',
    'vname' => 'LBL_CALL_TYPE',
    'type' => 'enum',
    'len' => 100,
    'options' => 'call_type_dom',
);
 $dictionary["Call"]["fields"]["description"]['cols'] = 60;
 