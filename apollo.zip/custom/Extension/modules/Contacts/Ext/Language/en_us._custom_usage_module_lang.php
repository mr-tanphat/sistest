<?php 
 // created: 2016-05-23 03:55:52

							$mod_strings['LBL_C_SMS'] = 'SMS';
							?>