<?php
 // created: 2014-07-15 14:40:52
$layout_defs["Contacts"]["subpanel_setup"]['c_classes_contacts_1'] = array (
  'order' => 100,
  'module' => 'C_Classes',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_C_CLASSES_CONTACTS_1_FROM_C_CLASSES_TITLE',
  'get_subpanel_data' => 'c_classes_contacts_1',
);
