<?php
 // created: 2014-04-12 00:27:35
$layout_defs["Contacts"]["subpanel_setup"]['contacts_c_payments_1'] = array (
  'order' => 100,
  'module' => 'C_Payments',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CONTACTS_C_PAYMENTS_1_FROM_C_PAYMENTS_TITLE',
  'get_subpanel_data' => 'contacts_c_payments_1',
);
