<?php
 // created: 2015-09-07 09:33:54
$layout_defs["Contacts"]["subpanel_setup"]['contacts_j_ptresult_1'] = array (
  'order' => 100,
  'module' => 'J_PTResult',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CONTACTS_J_PTRESULT_1_FROM_J_PTRESULT_TITLE',
  'get_subpanel_data' => 'contacts_j_ptresult_1',
);
