<?php
 // created: 2015-08-14 09:21:53
$layout_defs["Contacts"]["subpanel_setup"]['j_class_contacts_1'] = array (
  'order' => 100,
  'module' => 'J_Class',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_J_CLASS_CONTACTS_1_FROM_J_CLASS_TITLE',
  'get_subpanel_data' => 'j_class_contacts_1',
);
