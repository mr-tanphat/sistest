<?php
 // created: 2015-07-08 11:26:49
$layout_defs["Contacts"]["subpanel_setup"]['contacts_cases_1'] = array (
  'order' => 100,
  'module' => 'Cases',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CONTACTS_CASES_1_FROM_CASES_TITLE',
  'get_subpanel_data' => 'contacts_cases_1',
);
