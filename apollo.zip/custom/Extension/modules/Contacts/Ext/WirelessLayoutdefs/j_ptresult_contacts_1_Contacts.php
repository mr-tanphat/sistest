<?php
 // created: 2015-08-25 11:31:05
$layout_defs["Contacts"]["subpanel_setup"]['j_ptresult_contacts_1'] = array (
  'order' => 100,
  'module' => 'J_PTResult',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_J_PTRESULT_CONTACTS_1_FROM_J_PTRESULT_TITLE',
  'get_subpanel_data' => 'j_ptresult_contacts_1',
);
