<?php
 // created: 2014-04-12 00:26:05
$layout_defs["Contacts"]["subpanel_setup"]['contacts_c_invoices_1'] = array (
  'order' => 100,
  'module' => 'C_Invoices',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CONTACTS_C_INVOICES_1_FROM_C_INVOICES_TITLE',
  'get_subpanel_data' => 'contacts_c_invoices_1',
);
