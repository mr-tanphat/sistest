<?php
// created: 2014-04-12 00:26:05
$dictionary["Contact"]["fields"]["contacts_c_invoices_1"] = array (
  'name' => 'contacts_c_invoices_1',
  'type' => 'link',
  'relationship' => 'contacts_c_invoices_1',
  'source' => 'non-db',
  'module' => 'C_Invoices',
  'bean_name' => 'C_Invoices',
  'vname' => 'LBL_CONTACTS_C_INVOICES_1_FROM_CONTACTS_TITLE',
  'id_name' => 'contacts_c_invoices_1contacts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
