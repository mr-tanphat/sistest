<?php
// created: 2014-04-12 00:27:35
$dictionary["Contact"]["fields"]["contacts_c_payments_1"] = array (
  'name' => 'contacts_c_payments_1',
  'type' => 'link',
  'relationship' => 'contacts_c_payments_1',
  'source' => 'non-db',
  'module' => 'C_Payments',
  'bean_name' => 'C_Payments',
  'vname' => 'LBL_CONTACTS_C_PAYMENTS_1_FROM_CONTACTS_TITLE',
  'id_name' => 'contacts_c_payments_1contacts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
