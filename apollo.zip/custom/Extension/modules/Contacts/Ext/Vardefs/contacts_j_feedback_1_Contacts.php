<?php
// created: 2015-07-16 08:57:21
$dictionary["Contact"]["fields"]["contacts_j_feedback_1"] = array (
  'name' => 'contacts_j_feedback_1',
  'type' => 'link',
  'relationship' => 'contacts_j_feedback_1',
  'source' => 'non-db',
  'module' => 'J_Feedback',
  'bean_name' => 'J_Feedback',
  'vname' => 'LBL_CONTACTS_J_FEEDBACK_1_FROM_CONTACTS_TITLE',
  'id_name' => 'contacts_j_feedback_1contacts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
