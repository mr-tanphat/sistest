<?php
// created: 2015-08-14 09:21:53
$dictionary["Contact"]["fields"]["j_class_contacts_1"] = array (
  'name' => 'j_class_contacts_1',
  'type' => 'link',
  'relationship' => 'j_class_contacts_1',
  'source' => 'non-db',
  'module' => 'J_Class',
  'bean_name' => 'J_Class',
  'vname' => 'LBL_J_CLASS_CONTACTS_1_FROM_J_CLASS_TITLE',
  'id_name' => 'j_class_contacts_1j_class_ida',
);
