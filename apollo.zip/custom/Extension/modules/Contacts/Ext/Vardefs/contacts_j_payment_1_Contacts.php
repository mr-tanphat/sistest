<?php
// created: 2015-07-14 16:44:03
$dictionary["Contact"]["fields"]["contacts_j_payment_1"] = array (
  'name' => 'contacts_j_payment_1',
  'type' => 'link',
  'relationship' => 'contacts_j_payment_1',
  'source' => 'non-db',
  'module' => 'J_Payment',
  'bean_name' => 'J_Payment',
  'vname' => 'LBL_CONTACTS_J_PAYMENT_1_FROM_CONTACTS_TITLE',
  'id_name' => 'contacts_j_payment_1contacts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
