<?php
 // created: 2015-09-10 09:42:14
$dictionary['Contact']['fields']['primary_address_state']['required']=false;
$dictionary['Contact']['fields']['primary_address_state']['comments']='State for primary address';
$dictionary['Contact']['fields']['primary_address_state']['merge_filter']='disabled';
$dictionary['Contact']['fields']['primary_address_state']['calculated']=false;

 ?>