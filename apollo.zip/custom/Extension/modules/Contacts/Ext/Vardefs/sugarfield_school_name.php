<?php
 // created: 2015-08-05 15:48:31
$dictionary['Contact']['fields']['school_name']['required']=true;
$dictionary['Contact']['fields']['school_name']['merge_filter']='disabled';
$dictionary['Contact']['fields']['school_name']['calculated']=false;

 ?>