<?php
 // created: 2015-09-10 09:41:47
$dictionary['Contact']['fields']['primary_address_city']['required']=false;
$dictionary['Contact']['fields']['primary_address_city']['comments']='City for primary address';
$dictionary['Contact']['fields']['primary_address_city']['merge_filter']='disabled';
$dictionary['Contact']['fields']['primary_address_city']['calculated']=false;

 ?>