<?php
 // created: 2015-09-13 07:14:26
$dictionary['Contact']['fields']['custom_checkbox_class']['merge_filter']='disabled';
$dictionary['Contact']['fields']['custom_checkbox_class']['calculated']=false;

 ?>