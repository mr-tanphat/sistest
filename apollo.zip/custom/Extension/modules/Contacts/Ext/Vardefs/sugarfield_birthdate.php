<?php
 // created: 2015-08-05 15:47:38
$dictionary['Contact']['fields']['birthdate']['required']=true;
$dictionary['Contact']['fields']['birthdate']['comments']='The birthdate of the contact';
$dictionary['Contact']['fields']['birthdate']['merge_filter']='disabled';
$dictionary['Contact']['fields']['birthdate']['calculated']=false;
$dictionary['Contact']['fields']['birthdate']['enable_range_search']=true;
$dictionary['Contact']['fields']['birthdate']['options']='date_range_search_dom';

 ?>