<?php
 // created: 2015-08-05 15:44:00
$dictionary['Contact']['fields']['description']['comments']='Full text of the note';
$dictionary['Contact']['fields']['description']['merge_filter']='disabled';
$dictionary['Contact']['fields']['description']['calculated']=false;
$dictionary['Contact']['fields']['description']['rows']='4';
$dictionary['Contact']['fields']['description']['cols']='60';

 ?>