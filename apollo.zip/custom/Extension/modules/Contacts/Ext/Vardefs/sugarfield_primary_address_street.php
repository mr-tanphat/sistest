<?php
 // created: 2015-08-29 12:04:49
$dictionary['Contact']['fields']['primary_address_street']['required']=true;
$dictionary['Contact']['fields']['primary_address_street']['comments']='Street address for primary address';
$dictionary['Contact']['fields']['primary_address_street']['merge_filter']='disabled';
$dictionary['Contact']['fields']['primary_address_street']['calculated']=false;

 ?>