<?php
//auto-generated file DO NOT EDIT
$layout_defs['Contacts']['subpanel_setup']['student_j_gradebookdetail']['override_subpanel_name'] = 'Contact_subpanel_student_j_gradebookdetail';
?>