<?php
//auto-generated file DO NOT EDIT
$layout_defs['Contacts']['subpanel_setup']['contacts_contacts_1']['override_subpanel_name'] = 'Contact_subpanel_contacts_contacts_1';
?>