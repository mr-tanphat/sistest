<?php
//auto-generated file DO NOT EDIT
$layout_defs['Contacts']['subpanel_setup']['meetings_contacts_demo']['override_subpanel_name'] = 'Contact_subpanel_meetings_contacts_demo';
?>