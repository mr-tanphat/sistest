<?php
//auto-generated file DO NOT EDIT
$layout_defs['Contacts']['subpanel_setup']['contacts_j_ptresult_1']['override_subpanel_name'] = 'Contact_subpanel_contacts_j_ptresult_1';
?>