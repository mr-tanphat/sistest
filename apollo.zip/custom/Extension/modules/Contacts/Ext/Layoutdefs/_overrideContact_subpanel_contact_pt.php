<?php
//auto-generated file DO NOT EDIT
$layout_defs['Contacts']['subpanel_setup']['contact_pt']['override_subpanel_name'] = 'Contact_subpanel_contact_pt';
?>