<?php
 // created: 2015-09-23 15:23:34
$layout_defs["Contacts"]["subpanel_setup"]['leads_contacts_1'] = array (
  'order' => 100,
  'module' => 'Leads',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_LEADS_CONTACTS_1_FROM_LEADS_TITLE',
  'get_subpanel_data' => 'leads_contacts_1',
  'top_buttons' => 
  array (
//    0 => 
//    array (
//      'widget_class' => 'SubPanelTopButtonQuickCreate',
//    ),
//    1 => 
//    array (
//      'widget_class' => 'SubPanelTopSelectButton',
//      'mode' => 'MultiSelect',
//    ),
  ),
);
