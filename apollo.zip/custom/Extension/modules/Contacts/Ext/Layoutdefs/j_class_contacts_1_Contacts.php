<?php
 // created: 2015-08-14 09:21:53
$layout_defs["Contacts"]["subpanel_setup"]['j_class_contacts_1'] = array (
  'order' => 51,
  'module' => 'J_Class',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_J_CLASS_CONTACTS_1_FROM_J_CLASS_TITLE',
  'get_subpanel_data' => 'j_class_contacts_1',
  'top_buttons' => 
  array (
    //0 => 
//    array (
//      'widget_class' => 'SubPanelTopButtonQuickCreate',
//    ),
//    1 => 
//    array (
//      'widget_class' => 'SubPanelTopSelectButton',
//      'mode' => 'MultiSelect',
//    ),
  ),
);
