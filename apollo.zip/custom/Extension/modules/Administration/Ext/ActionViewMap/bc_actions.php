<?php

 $action_view_map['surveysmtp'] = 'surveysmtp';