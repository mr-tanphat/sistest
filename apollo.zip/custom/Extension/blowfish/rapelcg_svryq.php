<?php
// created: 2014-03-01 15:32:18
$key = array (
  0 => 'ddca8e89-cad1-134a-3f56-53119be5766e',
);