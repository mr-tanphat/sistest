<?php
// created: 2016-04-14 09:24:02
$key = array (
  0 => 'cbd70cbb-211d-8e87-dc0b-570eff0ebb02',
);