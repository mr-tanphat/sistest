<?php
// created: 2014-07-16 05:11:43
$mod_strings = array (
  'LBL_GRADEBOOK_ID' => 'Gradebook ID',
  'LBL_GRADEBOOK_NAME' => 'Gradebook Name',
  'LBL_STUDENT_ID' => 'Student ID',
  'LBL_STUDENT_NAME' => 'Student Name',
  'LBL_SCORE1' => 'Fluency',
  'LBL_SCORE2' => 'Coherence',
  'LBL_SCORE3' => 'Vocab',
  'LBL_SCORE4' => 'Grammar',
  'LBL_SCORE5' => 'Pron',
  'LBL_TOTAL1' => 'Teacher’s Recommendations ',
  'LBL_SEND_SMS' => 'Send SMS',
);