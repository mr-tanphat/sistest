<?php
    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    require_once('include/MVC/View/views/view.detail.php');

    class C_GradebookViewDetail extends ViewDetail {

        function C_GradebookViewDetail(){
            parent::ViewDetail();
        }

        function display() {
            //CUstom Buttom Input Score - Lap Nguyen
            $bt = '<input type="button" id="input_gradebook" value="'.$GLOBALS['mod_strings']['LBL_INPUT'].'" onclick="location.href=\'index.php?module=C_Gradebook&action=scoreTable&class_id='.$this->bean->class_id.'&gradebook_id='.$this->bean->id.'\'"/>';
            $this->ss->assign('TABLESCORE',$bt);
            
            parent::display();
        }
    }
?>