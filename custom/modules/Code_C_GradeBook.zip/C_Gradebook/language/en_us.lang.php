<?php
// created: 2014-07-16 05:11:43
$mod_strings = array (
  'LBL_GRADEBOOK_DETAIL' => 'Gradebook Detail',
  'LBL_CLASS_NAME' => 'Class Name',
  'LBL_SCORE' => 'Gradebook Name',
  'LBL_INPUT' => 'Input Gradebook',
  'LBL_FIND' => 'Find',
  'LBL_CLEAR' => 'Clear',
  'LBL_ERROR1' => 'Gradebook is not found.',
  'LBL_CHOOSE_ONE' => 'Please select at least one student!',
  'LBL_SMS_SUCCESS' => 'SMS Sent!',
);