<?php
 $cr_list = $_POST['create_list'];
 $up_list = $_POST['update_list'];
 $class = BeanFactory::getBean('C_Classes',$_POST['class_id']);
 
 for($i = 0; $i < count($cr_list); $i++){
     $dt = new C_GradebookDetail();
     $dt->name = $class->name;
     $dt->score1 = $cr_list[$i]['score1'];
     $dt->score2 = $cr_list[$i]['score2'];
     $dt->score3 = $cr_list[$i]['score3'];
     $dt->score4 = $cr_list[$i]['score4'];
     $dt->score5 = $cr_list[$i]['score5'];
     $dt->total1 = $cr_list[$i]['total1'];
     
     $dt->student_id = $cr_list[$i]['student_id'];
     $dt->gradebook_id = $_POST['gradebook_id'];
     $dt->save();
 }
 
  for($i = 0; $i < count($up_list); $i++){
     $dt = BeanFactory::getBean('C_GradebookDetail',$up_list[$i]['detail_id']);
     $dt->name = $class->name;
     $dt->score1 = $up_list[$i]['score1'];
     $dt->score2 = $up_list[$i]['score2'];
     $dt->score3 = $up_list[$i]['score3'];
     $dt->score4 = $up_list[$i]['score4'];
     $dt->score5 = $up_list[$i]['score5'];
     $dt->total1 = $up_list[$i]['total1'];
     $dt->save();
 }
 
 echo json_encode(array(
            "success" => "1",
        ));
