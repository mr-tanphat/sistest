function set_return(popup_reply_data) {
    from_popup_return = true;
    var form_name = popup_reply_data.form_name;
    var name_to_value_array = popup_reply_data.name_to_value_array;
    if (typeof name_to_value_array != 'undefined' && name_to_value_array['account_id']) {
        var label_str = '';
        var label_data_str = '';
        var current_label_data_str = '';
        var popupConfirm = popup_reply_data.popupConfirm;
        for (var the_key in name_to_value_array) {
            if (the_key == 'toJSON') {} else {
                var displayValue = replaceHTMLChars(name_to_value_array[the_key]);
                if (window.document.forms[form_name] && document.getElementById(the_key + '_label') && !the_key.match(/account/)) {
                    var data_label = document.getElementById(the_key + '_label').innerHTML.replace(/\n/gi, '').replace(/<\/?[^>]+(>|$)/g, "");
                    label_str += data_label + ' \n';
                    label_data_str += data_label + ' ' + displayValue + '\n';
                    if (window.document.forms[form_name].elements[the_key]) {
                        current_label_data_str += data_label + ' ' + window.document.forms[form_name].elements[the_key].value + '\n';
                    }
                }
            }
        }
        if (label_data_str != label_str && current_label_data_str != label_str) {
            if (typeof popupConfirm != 'undefined') {
                if (popupConfirm > -1) {
                    set_return_basic(popup_reply_data, /\S/);
                } else {
                    set_return_basic(popup_reply_data, /account/);
                }
            } else if (confirm(SUGAR.language.get('app_strings', 'NTC_OVERWRITE_ADDRESS_PHONE_CONFIRM') + '\n\n' + label_data_str)) {
                set_return_basic(popup_reply_data, /\S/);
            } else {
                set_return_basic(popup_reply_data, /account/);
            }
        } else if (label_data_str != label_str && current_label_data_str == label_str) {
            set_return_basic(popup_reply_data, /\S/);
        } else if (label_data_str == label_str) {
            set_return_basic(popup_reply_data, /account/);
        }
    } else {
        set_return_basic(popup_reply_data, /\S/);
    }
    ajaxGetGradeList();
}

function validateElements(){
    if(validate['scoreTableForm']!='undefined'){delete validate['scoreTableForm']};
    //Validate Start date - End date - Class
    addToValidate('scoreTableForm', 'class_name', 'text', true, SUGAR.language.get('C_Classes','LBL_CLASS') );
    addToValidateBinaryDependency('scoreTableForm', 'class_name', 'alpha', true, SUGAR.language.get('app_strings', 'ERR_SQS_NO_MATCH_FIELD') + SUGAR.language.get('C_Classes','LBL_CLASS') , 'class_id' );
    addToValidate('scoreTableForm', 'gradebook_id', 'enum', true, SUGAR.language.get('C_Gradebook','LBL_SCORE') );

    return check_form('scoreTableForm');
}
function ajaxGetGradeList(){
    $('td#gradebook_select').html('');
    $("#gradebook_select").append("<span id='loadding'></span>");   
    $("#loadding").html('<img src="custom/include/images/loader.gif" align="absmiddle" width="16">');
    var class_id = $("#class_id").val();
    $.ajax({
        url: "index.php?module=C_Gradebook&action=ajaxGetGradeList&sugar_body_only=true",
        type: "POST",
        async: true,
        data:  
        {
            class_id: class_id,
        },
        dataType: "json",
        success: function(data){           
            if(data.success == "1"){
                $('td#gradebook_select').html(data.html);             
            }else{
                alertify.error(SUGAR.language.get('C_Gradebook','LBL_ERROR1'));
            }
            $("#loadding").remove();  
        },        
    });
}
function ajaxGetTableScore(){
    $('#ct_find, #btn_select_class, #class_name, #gradebook_id').prop('disabled',true);
    ajaxStatus.showStatus('Loading <img src="custom/include/images/dots32.gif" align="absmiddle" width="32">');
    var class_id = $("#class_id").val();
    var gradebook_id = $("#gradebook_id").val();
    $.ajax({
        url: "index.php?module=C_Gradebook&action=ajaxGetTableScore&sugar_body_only=true",
        type: "POST",
        async: true,
        data:  
        {
            class_id: class_id,
            gradebook_id: gradebook_id,
        },
        dataType: "json",
        success: function(data){           
            if(data.success == "1"){
                $('div#result_table').html(data.html);             
            }
            ajaxStatus.hideStatus(); 
        },        
    });
}
function ajaxSaveTable(){
    ajaxStatus.showStatus('Saving <img src="custom/include/images/dots32.gif" align="absmiddle" width="32">'); //Sugar alert
    var class_id = $("#class_id").val();
    var gradebook_id = $("#gradebook_id").val();
    var create_list = [];
    $("tr[type='create']").each(function(){
        var row = {
            student_id: $(this).attr('student_id'),
            score1: $(this).find('td#score1').text(),
            score2: $(this).find('td#score2').text(),
            score3: $(this).find('td#score3').text(),
            score4: $(this).find('td#score4').text(),
            score5: $(this).find('td#score5').text(),
            total1: $(this).find('td.teacher_comment').text(),
        };
        create_list.push(row);
    });
    var update_list = [];
    $("tr[type='update']").each(function(){
        var row = {
            detail_id: $(this).attr('detail_id'),
            score1: $(this).find('td#score1').text(),
            score2: $(this).find('td#score2').text(),
            score3: $(this).find('td#score3').text(),
            score4: $(this).find('td#score4').text(),
            score5: $(this).find('td#score5').text(),
            total1: $(this).find('td.teacher_comment').text(),
        };        
        update_list.push(row);
    });

    $.ajax({
        url: "index.php?module=C_Gradebook&action=ajaxSaveTable&sugar_body_only=true",
        type: "POST",
        async: true,
        data:  
        {
            update_list: update_list,
            create_list: create_list,
            class_id: class_id,
            gradebook_id: gradebook_id,
        },
        dataType: "json",
        success: function(data){           
            if(data.success == "1"){
                ajaxGetTableScore();             
            }
        },        
    });   
}


//create by leduytan Send SMS
function ajaxSendSMS(){
    var gradebook_id = $('#gradebook_id').val();
    var class_name = $('#class_name').val();
    var gradebook_name = $('#gradebook_id option:selected').html() 
    var student_id = [];
    $("input[class='cb_sms']").each(function(){
        if($(this).is(':checked'))  
            student_id.push($(this).val());
    });
    if(student_id == 0){
        alertify.error(SUGAR.language.get('C_Gradebook','LBL_CHOOSE_ONE'));
        return;
    }
    else{
        ajaxStatus.showStatus('Sending SMS... Please wait, this will take less than a minute...');
        var record = $("input[name='record']").val();
        $.ajax({
            url: "index.php?module=C_Gradebook&action=sendSMSStudent&sugar_body_only=true",
            type: "POST",
            async: true,
            data:  
            {
                student_id: student_id,
                record: record,
                gradebook_id: gradebook_id,
                class_name: class_name,
                gradebook_name: gradebook_name,
            },
            dataType: "json",
            success: function(data){
                if(data.success == "1") 
                    alertify.success(SUGAR.language.get('C_Gradebook','LBL_SMS_SUCCESS'));
                else
                    alertify.error('Something error occurred. Please try again!');   
                ajaxStatus.hideStatus();
            }         
        });        
    }

}
//end Send SMS


$(document).ready(function(){
    $('#ct_find').click(function(){
        if(validateElements())
            ajaxGetTableScore();
    });
    $('#ct_clear').click(function(){
        $('#class_name, #class_id').val('');
        $('#gradebook_id').remove();
        $('div#result_table').html('');
        $('#ct_find, #btn_select_class, #class_name, #gradebook_id').prop('disabled',false);
    });
    // button select click event
    $('#btn_select_class').click(function(){
        open_popup("C_Classes", 600, 400, "", true, false, {"call_back_function":"set_return","form_name":"scoreTableForm","field_to_name_array":{"id":"class_id","name":"class_name"}});  
    });

    $('.cmm_select').live('change',function(){
        var select_id = $(this).attr('id');
        var input = $('select#'+select_id+' option:selected').text();
        if(input == '--- Select ---')
            return false;
        var comment = $('#cm_review').val();
        $('#cm_review').val(comment+' '+input);
    });

    $('.teacher_comment').live('click',function(){
        var current_comment = $(this).text();
        var target_id = $(this).attr('id');
        var st_name = $(this).closest('tr').find('.student_name').text();
        $('#cm_review').val(current_comment);
        $('#target_id').val(target_id);
        $('#student_name_cm').text('Student name: ' +st_name );
        $('#class_name_cm').text('Class: ' +$('#class_name').val() );
        $('.cmm_select').prop('selectedIndex',0);
        $('#lean_overlay, #signup').show();
    });

    $('#post_comment').live('click',function(){
        var current_comment =  $('#cm_review').val();
        var target_id = $('#target_id').val();
        $('#'+target_id).text(current_comment);
        $('#lean_overlay, #signup').hide();
    });
    $('.modal_close').live('click',function(){
        $('#lean_overlay, #signup').hide();
    });
});