<?php
    require_once("custom/modules/C_SMS/SMS/sms.php");

    //    $q1 = "SELECT name from c_gradebook where id = '{$_POST['gradebook_id']}'";
    //    $gradebook_name = $GLOBALS['db']->getOne($q1);

    //    $q3 = "SELECT name from c_gradebookdetail where gradebook_id = '{$_POST['gradebook_id']}'";
    //    $class_name = $GLOBALS['db']->getOne($q3);  



    foreach($_POST['student_id'] as $st_id){       
        $q2 = "SELECT CONCAT(IFNULL(contacts.last_name, ''),' ',IFNULL(contacts.first_name, '')) contacts_full_name, id, first_name, phone_mobile, other_mobile FROM contacts WHERE id = '$st_id' AND deleted = 0";
        $rs2 = $GLOBALS['db']->query($q2);
        $row2 = $GLOBALS['db']->fetchByAssoc($rs2);
        $row2['first_name'] != '' ? $name = $row2['first_name'] : $name = $row2['contacts_full_name'];

        //get Mark
        $q4 = "SELECT score1, score2, score3, score4, score5
        FROM c_gradebookdetail
        WHERE student_id = '$st_id' AND gradebook_id = '{$_POST['gradebook_id']}'";
        $rs4 = $GLOBALS['db']->query($q4);
        $row4 = $GLOBALS['db']->fetchByAssoc($rs4);
        $score1 = $row4[score1];
        $score2 = $row4[score2];
        $score3 = $row4[score3];
        $score4 = $row4[score4];
        $score5 = $row4[score5];


        $content = "Apollo360: Chao $name,".' Day la bang diem '.$_POST['gradebook_name'].' cua lop '.$_POST['class_name'];
        $content .= ' (Fluency: '.$score1.', Coherence: '.$score2.', Vocab: '.$score3.', Grammar: '.$score4.', Pron: '.$score5.') ';
        $content .= 'Xem chi tiet tai Student Portal';

        $tpls = new EmailTemplate();
        $tpls->retrieve_by_string_fields(array('name'=>'SMS TEMPLATE: SEND GRADEBOOK','deleted'=>0));
        $content = str_replace('@@name@@',$name,$tpls->body); 
        $content = str_replace('@@gradebook_name@@',$_POST['gradebook_name'],$content);
        $content = str_replace('@@class_name@@',$_POST['class_name'],$content);
        $content = str_replace('@@score1@@',$score1,$content);
        $content = str_replace('@@score2@@',$score2,$content);
        $content = str_replace('@@score3@@',$score3,$content);
        $content = str_replace('@@score4@@',$score4,$content);
        $content = str_replace('@@score5@@',$score5,$content);
        if(!isset($content)||empty($content))
        {
            echo json_encode(array(
                "success" => "0",
            ));
            return false;            
        }
        
        $sms = new sms();
        if(!empty($row2['phone_mobile']))
            $send1 = $sms->send_message($row2['phone_mobile'],$content,'Contacts',$row2['id']);

        if((int)$send1['return'] < 0){
            if(!empty($row2['other_mobile']))
                $send2 = $sms->send_message($row2['other_mobile'],$content,'Contacts',$row2['id']);  
        }
        //if((int)$send1['return'] > 0 || (int)$send2['return'] > 0){
        //            echo json_encode(array(
        //                "success" => "1",
        //            ));   
        //        }else{
        //            echo json_encode(array(
        //                "success" => "0",
        //            ));  
        //        } 
    }
    echo json_encode(array(
        "success" => "1",
    ));
?>
