<?php
    global $timedate;
    $today = $timedate->nowDbDate();
    $dates  = TimeDate::getInstance()->parseDateRange('this_month', null, true);
    $start  = $timedate->asDb($dates[0]);
    $end    = $timedate->asDb($dates[1]);
    isset($_REQUEST['weeks'])  ? $weeks = $_REQUEST['weeks'] : $weeks = 3;
    $q1 = "SELECT DISTINCT IFNULL(c_classes.id,'') primaryid ,IFNULL(c_classes.name,'') c_classes_name,  c_classes.start_date c_classes_start_date, c_classes.team_id classes_team_id, c_classes.assigned_user_id classes_assigned_user_id FROM c_classes WHERE (((c_classes.start_date < '$today' ) AND (c_classes.end_date > '$today' ))) AND c_classes.deleted=0 AND c_classes.type='Practice'";
    $rs1 = $GLOBALS['db']->query($q1);

    while($row = $GLOBALS['db']->fetchbyAssoc($rs1)){
        $q2 = "SELECT DISTINCT IFNULL(c_gradebook.id,'') primaryid ,IFNULL(c_gradebook.name,'') c_gradebook_name ,c_gradebook.date_entered c_gradebook_date_created, c_gradebook.date_input c_gradebook_date_input FROM c_gradebook INNER JOIN c_classes l1 ON c_gradebook.class_id=l1.id AND l1.deleted=0 WHERE (((l1.id='{$row['primaryid']}' ))) AND c_gradebook.deleted=0 ORDER BY c_gradebook_date_created DESC LIMIT 1";
        $rs2 = $GLOBALS['db']->query($q2);
        $row2 = $GLOBALS['db']->fetchbyAssoc($rs2);
        if(!$row2){
            $check_date = strtotime($row['c_classes_start_date']);     
        }else{
            $check_date = strtotime($row2['c_gradebook_date_input']);    
        }
        $check_date = strtotime('+'.$weeks.' weeks', $check_date);
        $today_int =  strtotime($today);
        if($check_date <= $today_int){
            
           $book = new C_Gradebook();
           $book->disable_row_level_security = true;
           $book->name = $row['c_classes_name'].': '.date('Y-m-d',$check_date);
           $book->class_id = $row['primaryid'];
           $book->date_input = date('Y-m-d',$check_date);
           $book->team_id = $row['classes_team_id'];
           $book->assigned_user_id = $row['classes_assigned_user_id'];
           $book->status = 'Not Approve';
           $book->description = 'Đây là bảng điểm tự động tạo ra';
           $book->save();   
        }
    }
?>
