<?php
    $sql = "SELECT * FROM c_gradebook WHERE class_id = '{$_POST['class_id']}' AND deleted = 0";
    $rs = $GLOBALS['db']->query($sql);
    $stt = 0;
    $html = "<select id='gradebook_id' name='gradebook_id'>";
    while($row = $GLOBALS['db']->fetchByAssoc($rs))
    {
        $html .= " <option value='{$row['id']}'>{$row['name']}</option>";
        $stt++;
    }
    if($stt>0){
        echo json_encode(array(
            "success" => "1",
            "html" => $html,
        ));   
    }else{
        echo json_encode(array(
            "success" => "0",
        ));
    }

