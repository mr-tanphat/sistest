<?php
    $class = BeanFactory::getBean('C_Classes',$_POST['class_id']);
    if($class->load_relationship('c_classes_contacts_1')){
        $list_student = $class->c_classes_contacts_1->getBeans();
        $html.= '<script type="text/javascript">        
        $(document).ready(function(){
        var table = $("#celebs");
        var oTable = table.dataTable({"sPaginationType": "full_numbers",

        "sDom": \'T<"clear">lfrtip\',
        "oTableTools": {
        "sSwfPath": "custom/include/javascripts/DataTables/swf/copy_csv_xls_pdf.swf",
        },
        "iDisplayLength": 100,
        "bStateSave": true, oLanguage:{
        "sLengthMenu": "'.$GLOBALS['app_strings']['LBL_JDATATABLE1'].'_MENU_'.$GLOBALS['app_strings']['LBL_JDATATABLE2'].'",
        "sZeroRecords": "'.$GLOBALS['app_strings']['LBL_JDATATABLE13'].'",
        "sInfo": "'.$GLOBALS['app_strings']['LBL_JDATATABLE6'].'_START_'.$GLOBALS['app_strings']['LBL_JDATATABLE7'].'_END_'.$GLOBALS['app_strings']['LBL_JDATATABLE8'].'_TOTAL_'.$GLOBALS['app_strings']['LBL_JDATATABLE2'].'",
        "sInfoEmpty": "'.$GLOBALS['app_strings']['LBL_JDATATABLE15'].'",
        "sEmptyTable": "'.$GLOBALS['app_strings']['LBL_JDATATABLE14'].'",
        "sInfoFiltered": "",
        "oPaginate": {
        "sFirst": "'.$GLOBALS['app_strings']['LBL_JDATATABLE9'].'",
        "sNext": "'.$GLOBALS['app_strings']['LBL_JDATATABLE10'].'",
        "sPrevious": "'.$GLOBALS['app_strings']['LBL_JDATATABLE11'].'",
        "sLast": "'.$GLOBALS['app_strings']['LBL_JDATATABLE12'].'",
        },
        "iTabIndex": 1,
        "sSearch": "'.$GLOBALS['app_strings']['LBL_JDATATABLE3'].'"
        },});

        var keys = new KeyTable( {
        "table": document.getElementById(\'celebs\')
        });
        /* Apply a return key event to each cell in the table */
        //keys.event.focus( 3, 3, function() {
        //console.log(keys.fnGetCurrentPosition());
        //} );
        keys.event.focus( null, null, function (nCell) {
        var kpos = keys.fnGetCurrentPosition();
        if(kpos[0] > 2 && kpos[0] < 8){

        $(nCell).editable(function (sVal) { return sVal; },{
        placeholder : "",
        width       : "80px",
        height      : "14px",
        onblur      : "submit",
        });
        setTimeout( function () { $(nCell).click(); }, 0 );
        }

        if(kpos[0] == 8){
        $(nCell).editable(function (sVal) { return sVal; },{
        placeholder : "",
        width       : "150px",
        height      : "14px",
        onblur      : "submit",
        type        : "select",
        data        : "'.getComments().'",
        });
        setTimeout( function () { $(nCell).click(); }, 0 );    
        }

        });
        });
        </script>';

        $html.= "<table width='100%' border='1' class='table' id='celebs'>";
        $html.= "<thead>";        
        $html.= "<tr>";            
        $html.= "<th width='5%' height = '20px'>No.</th>";                
        $html.= "<th width='8%'>Student ID</th>";                
        $html.= "<th width='15%'>Student Name</th>";
        $html.= "<th width='8%' class='center'>".translate('LBL_SCORE1','C_GradebookDetail')."</th>";          
        $html.= "<th width='8%' class='center'>".translate('LBL_SCORE2','C_GradebookDetail')."</th>";
        $html.= "<th width='8%' class='center'>".translate('LBL_SCORE3','C_GradebookDetail')."</th>";
        $html.= "<th width='8%' class='center'>".translate('LBL_SCORE4','C_GradebookDetail')."</th>";
        $html.= "<th width='8%' class='center'>".translate('LBL_SCORE5','C_GradebookDetail')."</th>";
        $html.= "<th width='17%' class='center'>".translate('LBL_TOTAL1','C_GradebookDetail')."</th>";
        $html.= "</tr>";            
        $html.= "</thead>";
        $html.= "<tbody>";

        $stt = 1;
        //Fetch each student in class
        foreach($list_student as $key => $value){
            $sql = "SELECT * FROM c_gradebookdetail WHERE gradebook_id='{$_POST['gradebook_id']}' AND student_id='$key' AND deleted = 0;";
            $rs = $GLOBALS['db']->query($sql);
            $row = $GLOBALS['db']->fetchByAssoc($rs);

            if($row['id'] != ''){
                $html.= "<tr type='update' detail_id='{$row['id']}'>";    
            }else{
                $html.= "<tr type='create' student_id='$key'>";   
            }

            $html.= "<td>$stt</td>";
            $html.= "<td>".$value->contact_id."</td>";
            $html.= "<td style='font-weight:bold;'>".$value->name."</td>";     

            $html.= "<td align='center' class='score' id='score1' height = '20px'>{$row['score1']}</td>"; 
            $html.= "<td align='center' class='score' id='score2'>{$row['score2']}</td>"; 
            $html.= "<td align='center' class='score' id='score3'>{$row['score3']}</td>"; 
            $html.= "<td align='center' class='score' id='score4'>{$row['score4']}</td>"; 
            $html.= "<td align='center' class='score' id='score5'>{$row['score5']}</td>"; 

            $html.= "<td align='center' class='teacher_comment' id='total1'>{$row['total1']}</td>"; 
            $html.= "</tr>";
            $stt++;    
        }
        $html.= "</tbody></table>";
        $button = '<div style="text-align: center; margin-top: 20px;"><input class="button primary" type="button" name="button_save" value="Save" id="button_save" style="padding: 6px 30px 6px 30px; margin: 0 auto;"></div>';

        $js = 
        <<<EOQ
    <script>
    $('#button_save').click(function(){
    setTimeout(function () {
            ajaxSaveTable();
        }, 500);      
        });
    </script>
EOQ;
        echo json_encode(array(
            "success" => "1",
            "html" => $html.$button.$js,     
        ));   
    }
    function getComments(){
        $sl = "{";
        foreach($GLOBALS['app_list_strings']['teacher_comment_list'] as $key => $value){
            $sl .= "'$key':'$value',";  
        }
        $sl .= '}';
        return $sl;    
    }
?>
