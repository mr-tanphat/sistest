<?php
    // create by Lap - Table Score
    function scoreTable(){
        $ss = new Sugar_Smarty();
        $ss->assign("MOD", $GLOBALS['mod_strings']);


        if(isset($_GET['class_id']) && isset($_GET['gradebook_id'])){
            $class = BeanFactory::getBean('C_Classes',$_GET['class_id']);
            $gradebook = BeanFactory::getBean('C_Gradebook',$_GET['gradebook_id']);
            $ss->assign("CLASS_NAME", $class->name);
            $ss->assign("CLASS_ID", $class->id);
            $ss->assign("GRADEBOOK_NAME", $gradebook->name);
            $ss->assign("GRADEBOOK_ID", $gradebook->id);
            
            $js = "<script>
            $(document).ready(function(){
            $('#ct_find').trigger('click');});
            </script>";
            
            $ss->assign("JS_TRIGGERCLICK", $js);
        }
        $ss->assign("CM1", get_select_options($GLOBALS['app_list_strings']['gradebook_overral_comment_list']));
        $ss->assign("CM2", get_select_options($GLOBALS['app_list_strings']['gradebook_participation_comment_list']));
        $ss->assign("CM3", get_select_options($GLOBALS['app_list_strings']['gradebook_speaking_comment_list']));
        $ss->assign("CM4", get_select_options($GLOBALS['app_list_strings']['gradebook_listening_comment_list']));
        $ss->assign("CM5", get_select_options($GLOBALS['app_list_strings']['gradebook_pronunciation_comment_list']));
        $ss->assign("CM6", get_select_options($GLOBALS['app_list_strings']['gradebook_vocabulary_comment_list']));
        $ss->assign("CM7", get_select_options($GLOBALS['app_list_strings']['gradebook_reading_comment_list']));
        $ss->assign("CM8", get_select_options($GLOBALS['app_list_strings']['gradebook_writing_comment_list']));

        return $ss->fetch('custom/modules/C_Gradebook/tpls/scoreTable.tpl');  
    }  
    echo  scoreTable();