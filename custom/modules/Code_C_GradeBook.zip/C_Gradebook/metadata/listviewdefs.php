<?php
$module_name = 'C_Gradebook';
$listViewDefs[$module_name] = 
array (
  'name' => 
  array (
    'width' => '20%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'CLASS_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_CLASS_NAME',
    'id' => 'CLASS_ID',
    'width' => '10%',
    'default' => true,
    'related_fields' => array('class_id'),//Custom Link Reletionship by code - Lap Nguyen
  ),
  'status' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_STATUS',
    'width' => '10%',
  ),
  'date_input' => 
  array (
    'type' => 'date',
    'label' => 'LBL_DATE_INPUT',
    'width' => '10%',
    'default' => true,
  ),
  'team_name' => 
  array (
    'width' => '9%',
    'label' => 'LBL_TEAM',
    'default' => true,
  ),
  'assigned_user_name' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => false,
  ),
);
